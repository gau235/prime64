 

 Certain portions of this software are based on source code from OpenJDK
(http://openjdk.java.net/)  and  licensed  under  the GNU General Public
License  version  2  (GPLv2)  with   the  Classpath  Exception  (http://
openjdk.java.net/legal/gplv2+ce.html).  For a period of three years from
the date  of your receipt  of  this  software,  Azul  will  provide upon
request, a complete  machine readable  copy of the  source code for such
portions  based  on  OpenJDK on a medium  customarily used  for software
interchange for a charge no more  than the cost of physically performing
source distribution.


  Please email azul_openjdk@azul.com for further information.

  Include this version code in your email:
  zsrc7.48.0.11-jdk7.0.312 2957403db94684c3c9a136ab9662d000c69c896b1fc78a368b215bb79eaa73ac013e5560f5f0f3c80b0fac239c70d5f885887bf4f9dba63c5456352a0f2491ef21ce4fcb8cd076a7129ad271975109ba2970865de0267bb962e15b4cc116889f93c291f7e3a09b181edd4060d1c6b917084567f500f8fdd289a1f1582a4918a6f302f6b3238ef4dc7995df65

