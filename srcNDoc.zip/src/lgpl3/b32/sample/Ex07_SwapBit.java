package lgpl3.b32.sample;

import lgpl3.b32.B32va;
import lgpl3.o.O;

/**
 * To swap bits.<br/>
 * To swap bits.
 *
 * @version 2023/06/07_19:00:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Ex07_SwapBit" >src</a>
 *
 */
public class Ex07_SwapBit {

	public static void main(String[] sAry) throws Throwable {

		int b32 = 0b10_1010;

		b32 = B32va.swapBit(b32, 3, 2);

		O.l("bef=" + B32va.str16(b32));

		b32 = B32va.swapBit(b32, 3, 2);

		O.l("aft=" + B32va.str16(b32));

	}
}
