package lgpl3.o.ary;

import java.util.Arrays;

import lgpl3.o.O;

/**
 * @version 2022/12/14_09:50:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Ary32va_U" >src</a>
 *
 * @see Ary32va
 */
public abstract class Ary32va_U extends Ary32va_A {

	private static final Class<?> THIS = Ary32va_U.class;

	/**
	 * To check if there is duplicated.<br/>
	 * To check if there is duplicated.
	 */
	public static int[] checkDup(int[] sortedAry32) {

		if (sortedAry32.length == 0)

			return sortedAry32;

		int idx = (sortedAry32.length - 1), tail = sortedAry32[idx], head;

		for (; idx > 0; tail = head)

			if (tail == (head = sortedAry32[--idx]))

				O.x("idx=" + idx);

		return sortedAry32;

	}

	/**
	 * To check if there is duplicated.<br/>
	 * To check if there is duplicated.
	 */
	public static int[] sortNCheckDup(int[] ary32) {

		if (ary32.length == 0)

			return ary32;

		Arrays.sort(ary32); // 破壞性寫入

		// java.util.DualPivotQuicksort.sort(ary, 0, ary.length - 1, null, 0, 0);

		int idx = (ary32.length - 1), tail = ary32[idx], head;

		for (; idx > 0; tail = head)

			if (tail == (head = ary32[--idx]))

				O.x("idx=" + idx);

		return ary32;

	}

	/**
	 * To check if there is duplicated.<br/>
	 * To check if there is duplicated.
	 */
	public static int[] sortDescNCheckDup(int[] ary32) {

		if (ary32.length == 0)

			return ary32;

		Arrays.sort(ary32); // 破壞性寫入

		// java.util.DualPivotQuicksort.sort(ary, 0, ary.length - 1, null, 0, 0);

		rev(ary32);

		int idx = (ary32.length - 1), tail = ary32[idx], head;

		for (; idx > 0; tail = head)

			if (tail == (head = ary32[--idx]))

				O.x("idx=" + idx);

		return ary32;

	}

	/**
	 * To distinct.<br/>
	 * To distinct.
	 *
	 * @see Aryva #distinct(long[])
	 */
	public static int[] distinct(int[] sortedAry32) {

		// max as king
		int max = sortedAry32[0], idx = 1, cnt = 1 /* 第一個已自動加入 */, tmpV;

		for (; idx != sortedAry32.length; idx++) // O.l("tmpV=" + sortedAry32[idx] + ", idx=" + idx + ", max=" + max);

			if ((tmpV = sortedAry32[idx]) != max)

				sortedAry32[cnt++] = max = tmpV; // 連用 2 個等號

		if (cnt != sortedAry32.length)

			System.arraycopy(sortedAry32, 0, (sortedAry32 = new int[cnt]), 0, cnt);

		return sortedAry32;

	}

	/**
	 * To distinct.
	 *
	 * @see Aryva #easyDistinct(long[])
	 */
	public static int[] easyDistinct(int[] sortedAry32) { // 2 份記憶體空間

		int idx, cache, ret[] = new int[sortedAry32.length], iRet;

		ret[0] = cache = sortedAry32[0]; // 連用 2 個等號

		for (iRet = idx = 1; idx != sortedAry32.length; idx++) // 連用 2 個等號

			if (sortedAry32[idx] != cache) // O.l("cache=" + sortedAry[idx] + ", iRet=" + iRet );

				ret[iRet++] = cache = sortedAry32[idx]; // 連用 2 個等號

		// O.l("iRet=" + iRet, THIS);
		if (iRet != sortedAry32.length)

			System.arraycopy(ret, 0, (ret = new int[iRet]), 0, iRet); // 使用原陣列當容器

		return ret;

	}

	/**
	 * To distinct.
	 *
	 * @see Aryva #merge(long[])
	 */
	public static int[] merge(int[] ary1, int[] ary2) {

		int[] ret = new int[ary1.length + ary2.length];

		System.arraycopy(ary1, 0, ret, 0, ary1.length);
		System.arraycopy(ary2, 0, ret, ary1.length, ary2.length);

		return ret;

	}

	/**
	 * To difference.
	 */
	public static int[] ex(int[] sortedAry32, int[] exAry32) {

		int idx = 0, len = sortedAry32.length, key32;

		int searchFrom = 0, searchTo = exAry32.length, retIdx, newLen = 0;

		for (; idx != len; idx++) {

			O.l("ex=" + Arrays.toString(Arrays.copyOfRange(exAry32, searchFrom, searchTo)));

			retIdx = Arrays.binarySearch(exAry32, searchFrom, searchTo, key32 = sortedAry32[idx]);

			O.l("retIdx=" + retIdx);

			O.l("(searchFrom + retIdx)=" + (searchFrom + retIdx));

			// -insertionPoint - 1

			if ((searchFrom + retIdx) < -1) // if (key != oldKey) { // changed

				searchFrom++; // O.l("searchFrom++ ");

			if (retIdx < 0)

				if (idx == newLen)

					++newLen;
				else
					sortedAry32[newLen++] = key32; // 使用原陣列當容器

		}

		if (newLen != len)

			System.arraycopy(sortedAry32, 0, (sortedAry32 = new int[newLen]), 0, newLen);

		return sortedAry32;

	}

	/**
	 * To convert.
	 */
	public static int[] toAry32(long[] ary) {

		int len = ary.length, ary32[] = new int[len];

		while (len-- != 0)

			ary32[len] = (int) ary[len];

		return ary32;

	}
}