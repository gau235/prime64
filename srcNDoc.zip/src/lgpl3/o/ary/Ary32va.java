package lgpl3.o.ary;

import java.util.Arrays;

import lgpl3.o.O;

/**
 * 本類別是使用 32 位元的整數陣列.<br/>
 * The array of 32 bit integer.
 *
 * @version 2022/04/14_09:50:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Ary32va" >Ary32va.java</a>
 *
 * @see Aryva
 */
public abstract class Ary32va extends Ary32va_A {

	private static final Class<?> THIS = Ary32va.class;

	/**
	 * To compare.<br/>
	 * To compare.
	 */
	public static int[] eq(int[] ary32A, int[] ary32B) {

		if (ary32A != ary32B) {

			if (ary32A == null || ary32B == null)

				O.x();

			int lenA = ary32A.length;

			if (ary32B.length != lenA)

				O.x();

			while (lenA-- != 0)

				if (ary32A[lenA] != ary32B[lenA])

					O.x();

		}

		return ary32A;

	}

	/**
	 * To check if there is duplicated.<br/>
	 * To check if there is duplicated.
	 */
	public static int[] checkDup(int[] sortedAry32) {

		if (sortedAry32.length == 0)

			return sortedAry32;

		int idx = (sortedAry32.length - 1), tail = sortedAry32[idx], head;

		for (; idx > 0; tail = head)

			if (tail == (head = sortedAry32[--idx]))

				O.x("idx=" + idx);

		return sortedAry32;

	}

	/**
	 * To check if there is duplicated.<br/>
	 * To check if there is duplicated.
	 */
	public static int[] sortNCheckDup(int[] ary32) {

		if (ary32.length == 0)

			return ary32;

		Arrays.sort(ary32); // 破壞性寫入

		// java.util.DualPivotQuicksort.sort(ary, 0, ary.length - 1, null, 0, 0);

		int idx = (ary32.length - 1), tail = ary32[idx], head;

		for (; idx > 0; tail = head)

			if (tail == (head = ary32[--idx]))

				O.x("idx=" + idx);

		return ary32;

	}

	/**
	 * To check if there is duplicated.<br/>
	 * To check if there is duplicated.
	 */
	public static int[] sortDescNCheckDup(int[] ary32) {

		if (ary32.length == 0)

			return ary32;

		Arrays.sort(ary32); // 破壞性寫入

		// java.util.DualPivotQuicksort.sort(ary, 0, ary.length - 1, null, 0, 0);

		rev(ary32);

		int idx = (ary32.length - 1), tail = ary32[idx], head;

		for (; idx > 0; tail = head)

			if (tail == (head = ary32[--idx]))

				O.x("idx=" + idx);

		return ary32;

	}

	/**
	 * To distinct.<br/>
	 * To distinct.
	 *
	 * @see Aryva#distinct(long[])
	 */
	public static int[] distinct(int[] sortedAry32) {

		int idx = 1, len = sortedAry32.length, newIdx = 1, max = sortedAry32[0], v;

		for (; idx != len; idx++) // O.l("v=" + sortedAry32[i] + ", idx=" + idx + ", max=" + max);

			if ((v = sortedAry32[idx]) != max) // if ((v = sortedAry32[i]) > max) {

				sortedAry32[newIdx++] = max = v; // 連用 2 個等號

		if (newIdx != len)

			System.arraycopy(sortedAry32, 0, (sortedAry32 = new int[newIdx]), 0, newIdx);

		return sortedAry32;

	}

	/**
	 * To distinct.
	 *
	 * @see Aryva #easyDistinct(long[])
	 */
	public static int[] easyDistinct(int[] sortedAry) { // 2 份記憶體空間

		int idx, len, cache, ret[] = new int[len = sortedAry.length], iRet;

		ret[0] = cache = sortedAry[0]; // 連用 2 個等號

		for (iRet = idx = 1; idx != len; idx++) // 連用 2 個等號

			if (sortedAry[idx] != cache) // O.l("v=" + sortedAry[idx] + ", iRet=" + iRet );

				ret[iRet++] = cache = sortedAry[idx]; // 連用 2 個等號

		// O.l("iRet=" + iRet, THIS);
		if (iRet != len)

			System.arraycopy(ret, 0, (ret = new int[iRet]), 0, iRet); // 使用原陣列當容器

		return ret;

	}

	/**
	 * To distinct.
	 *
	 * @see Aryva #merge(long[])
	 */
	public static int[] merge(int[] ary1, int[] ary2) {

		int[] ret = new int[ary1.length + ary2.length];

		System.arraycopy(ary1, 0, ret, 0, ary1.length);
		System.arraycopy(ary2, 0, ret, ary1.length, ary2.length);

		return ret;

	}

	/**
	 * To difference.
	 */
	public static int[] ex(int[] sortedAry32, int[] exAry32) {

		int idx = 0, len = sortedAry32.length, key32;

		int searchFrom = 0, searchTo = exAry32.length, retIdx, newLen = 0;

		for (; idx != len; idx++) {

			O.l("ex=" + Arrays.toString(Arrays.copyOfRange(exAry32, searchFrom, searchTo)));

			retIdx = Arrays.binarySearch(exAry32, searchFrom, searchTo, key32 = sortedAry32[idx]);

			O.l("retIdx=" + retIdx);

			O.l("(searchFrom + retIdx)=" + (searchFrom + retIdx));

			// -insertionPoint - 1

			if ((searchFrom + retIdx) < -1) // if (key != oldKey) { // changed

				searchFrom++; // O.l("searchFrom++ ");

			if (retIdx < 0)

				if (idx == newLen)

					++newLen;
				else
					sortedAry32[newLen++] = key32; // 使用原陣列當容器

		}

		if (newLen != len)

			System.arraycopy(sortedAry32, 0, (sortedAry32 = new int[newLen]), 0, newLen);

		return sortedAry32;

	}

	/**
	 * 10 元素, 15 次比較.
	 */
	public static int[] findMinMaxByAryOfEvenOdd(int[] ary) { // todo: ary.len 限制要偶數 才可執行

		// Aryva 要補上

		int idx, end = (ary.length >>> 1), vEven, vOdd, aryMin[] = new int[end], aryMax[] = new int[end], newIdx, min, max;

		for (idx = 0; idx != end; idx++) {

			newIdx = idx << 1; // O.l("newIdx=" + newIdx);

			if ((vEven = ary[newIdx]) < (vOdd = ary[newIdx + 1])) {

				aryMin[idx] = vEven;
				aryMax[idx] = vOdd;

			} else {

				aryMin[idx] = vOdd;
				aryMax[idx] = vEven;

			}
		}

		min = max = ary[0];

		for (idx = 0; idx != end; idx++) {

			if (aryMin[idx] < min)

				min = aryMin[idx];

			if (aryMax[idx] > max)

				max = aryMax[idx];

		}

		return new int[] { min, max };

	}

	/**
	 * To convert.
	 */
	public static int[] toAry32(long[] ary) {

		int len = ary.length;

		int[] ary32 = new int[len];

		while (len-- != 0)

			ary32[len] = (int) ary[len];

		return ary32;

	}
}