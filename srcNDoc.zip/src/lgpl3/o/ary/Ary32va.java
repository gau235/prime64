package lgpl3.o.ary;

import java.util.Arrays;

import lgpl3.o.O;

/**
 * 本類別是使用 32 位元的整數陣列.<br/>
 * The array of 32 bit integer.
 *
 * @version 2022/12/14_09:50:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Ary32va" >src</a>
 *
 * @see Aryva
 */
public abstract class Ary32va extends Ary32va_U {

	private static final Class<?> THIS = Ary32va.class;

	/**
	 * 奇數位置值跟偶數位置值抓出來互比, 大的放一組, 小的放另一組.<br/>
	 * 10 元素, 15 次比較.
	 */
	public static int[] findMinMax(int[] ary) { // Aryva 也要補上

		int min = ary[0], max = ary[0], tmpV;

		for (int idx = 1; idx != ary.length; idx++)

			if ((tmpV = ary[idx]) > max) // O.l("v=" + v);

				max = tmpV;

			else if (tmpV < min)

				min = tmpV;

		return new int[] { min, max };

	}

	/**
	 * 奇數位置值跟偶數位置值抓出來互比, 大的放一組, 小的放另一組.<br/>
	 * 10 元素, 15 次比較.
	 */
	public static int[] findMinMaxByGroupEvenOdd(int[] ary) {

		int len = ary.length, lenDiv2 = (len >>> 1), idx, vEven, vOdd, aryMin[] = new int[lenDiv2],

				aryMax[] = new int[lenDiv2], newIdx, min, max;

		for (idx = 0; idx != lenDiv2; idx++) {

			newIdx = idx << 1; // O.l("newIdx=" + newIdx);

			if ((vEven = ary[newIdx]) < (vOdd = ary[newIdx + 1])) {

				aryMin[idx] = vEven;
				aryMax[idx] = vOdd;

			} else {

				aryMin[idx] = vOdd;
				aryMax[idx] = vEven;

			}
		}

		min = aryMin[0];
		max = aryMax[0];

		for (idx = 1 /* it is one */; idx != lenDiv2; idx++) {

			if ((vOdd = aryMin[idx]) < min)

				min = vOdd;

			if ((vOdd = aryMax[idx]) > max)

				max = vOdd;

		}

		if ((len & 0b1) != 0b0) { // 貼心檢查

			vOdd = ary[len - 1];

			if (O.isDev) {

				O.l("min=" + min);
				O.l("max=" + max);
				O.l("vOdd=" + vOdd);

			}

			if (vOdd < min)

				min = vOdd;

			else if (vOdd > max)

				max = vOdd;

		}

		return new int[] { min, max };

	}

	/**
	 * 奇數位置值跟偶數位置值抓出來互比, 大的放一組, 小的放另一組.<br/>
	 * 10 元素, 15 次比較.
	 */
	public static int[] findMinMaxByGroupHeadTail(int[] ary) {

		int len = ary.length, lenDiv2 = (len >>> 1), idx, vHead, vTail, aryMin[] = new int[lenDiv2],

				aryMax[] = new int[lenDiv2], min, max, tmpV;

		for (idx = 0; idx != lenDiv2; idx++) { // to group, the small ones => aryMin, the big ones => aryMax

			if ((vHead = ary[idx]) < (vTail = ary[ary.length - 1 - idx])) {

				aryMin[idx] = vHead;
				aryMax[idx] = vTail;

			} else {

				aryMin[idx] = vTail;
				aryMax[idx] = vHead;

			}
		}

		min = aryMin[0];
		max = aryMax[0];

		for (idx = 1 /* it is one */; idx != lenDiv2; idx++) {

			if ((tmpV = aryMin[idx]) < min) // check elem in aryMin

				min = tmpV;

			if ((tmpV = aryMax[idx]) > max) // check elem in aryMax

				max = tmpV;

		}

		if ((len & 0b1) != 0b0) // 貼心檢查

			if ((tmpV = ary[lenDiv2]) < min)

				min = tmpV;

			else if (tmpV > max)

				max = tmpV;

		return new int[] { min, max };

	}

	/**
	 * To partition.<br/>
	 * To partition.
	 */
	public static int partiNRetIdxOfPivot(int[] ary32, int left, int right) {

		int pivotIdx = left;

		int pivot = ary32[pivotIdx];

		for (int from = left + 1; from <= right; from++) {

			if (ary32[from] < pivot) {

				pivotIdx++;

				// if (from != pivotIdx)
				swapV(ary32, from, pivotIdx);

				O.l("swap=>" + Arrays.toString(ary32));

			}
		}

		swapV(ary32, left, pivotIdx); // 跟小朋友群內, 最後加入的小朋友交換

		O.l("finSwap=>" + Arrays.toString(ary32));

		return pivotIdx;

	}
}