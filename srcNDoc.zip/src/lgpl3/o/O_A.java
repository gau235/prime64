package lgpl3.o;

import java.util.concurrent.ThreadLocalRandom;

/**
 * @version 2023/05/14_00:00:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=O_A" >src</a>
 *
 * @see O_M
 */
public abstract class O_A extends Origin {

	// 認為世界是離散的 學科學 工業較容易

	// 新時代 極權主義 新樣態存在 如企業

	// 數學 歐洲人 思想存摺 (歐洲人不勤勞 但懂得存)

	// 熟能生巧 溫故知新
	// 殷憂啟聖
	// 前事不忘 後事之師

	// 強假設:
	// 光速定植 時間膨脹
	// 根號 2 無理數
	// 質數有無限多
	// D 函數 Dn=(n-1)(Dn-1 + Dn-2)
	// 10~30 質數數目 == 10~20 質數數目 + 20~30 質數數目
	// 鴿籠原理算嗎

	// value tmp 要改 tmpV

	// 波粒二象性 (執政黨 反對黨) 暴漲理論 (物價上漲) 科學被時代潮流影響

	// 科學客觀 vs 設計主觀 人類 再平衡

	// 有價無市 古董 有市無價 軟體

	// 科學重要的是推翻 而不是發現 (科學家 對教會而言 是反對黨)

	// 科學家 也不是 一輩子大部分時間 都很理性

	// 數學 科學基本假設 沒辦法解釋
	// 根據上帝給定而來 如 C(2,0) = 1
	// 上帝規定 科學家丟給上帝 上帝為靠山

	// 宇宙是一部機器 上帝給定初始值
	// 上帝 設定好之後 不管他 讓機器去運轉

	// 理性思考 在數學之前

	// 科學發揚理性 延伸理性

	// 科學是一點一點悟出來的

	// 學數學 翻過門檻 翻過高牆 想前進到 主屋門口
	// 踏著前人走過的血路

	// 我認為 數學是離散的 不連續的

	// 數學是離散的 面積 5X5 是方陣 隊伍 而非面積

	// 幾何學 不是數學 (好東西 給出去 障眼法補救)

	// 反向思考 多人開發軟體不可行
	// 換個角度 減法原則 想如何退場 才是重點

	// 數學 國際共通語言

	// 中華文明 欠缺數學
	// 中華文明 有孫文革命 應該要有一場數學革命

	// 數學很久無革命了

	// 金庸根本性錯誤 倚天盾 (先求自保) 屠龍刀
	// 剛性民族 日本(工筆) 柔性 中華(水墨)
	// 科學追求清楚 政治保持模糊

	// 人類傾向把複雜化簡 如畢氏定理 輸入 2 短邊 return 斜邊 這樣可行
	// 但是遇到 C(5,3) 列出所有樣態 人類會抗拒, 然而也開啟新領域的一扇門

	// 數學 vs 工程
	// add ext tail
	// subtract dif
	// mul cross product
	// div circle, CartePro 加上左小於右的條件嗎

	// 上帝對軟體限制:
	// 數學 (軟體) 不可故事接龍 (一人寫一段接起來 除非數學架構很完整)
	// 需要背舊包袱

	// 數學沒辦法 多人討論
	// 看一個外星球文明發展 看他們有辦法討論數學

	// 西洋人喜歡 圖片 放大多少倍 加多少 Y= 4X+3
	// 西洋人喜歡 y=ax+b 斜率多少 平移多少
	// 西洋人喜歡 分成多少箱 還剩多少 a = bq + r

	// aaa=-1 shift >>> 31 後 shift 1 不等於 aaa shift 32

	// String.replaceFirst(s1, s2); // when call replaceFirst but java's bug

	// 在Windows中：
	// '\r' 回到行首，而不会换到下一行，如果接着输出的话，本行以前的内容会被逐一覆盖
	//
	// '\n' 换行，换到当前位置的下一行，而不会回到行首；

	// chinese-utils-1.0 金為部首, 如銅 銀 鉤 釣 轉簡體字太笨了

	// 整個排列組合就是判斷什麼叫'同' 什麼叫'不同'

	// 排列先取再排 (用組合實做)
	// P(5,3) = C(5,3)*3!

	// 組合用有序排列實作 (用排列實做)
	// 從黑箱取 2 物先左手抓第 1 物, 後右手抓第 2 物 (有序)
	// C(5,3) = 5取1 * 4取1 * 3取1 後除以 3!
	// => P(5,1)*P(4,1)*P(3,1) / 3 ! 即連續一個一個取, 是排列

	// 排列組合, 少用除法
	// 電腦沒有減法, ex: 5 顆球 減法減掉 3 顆球 剩下 2 顆球, 記憶體使用愈用愈多.
	// 搬家不是搬房屋, 而是搬人; 土地面積不會消失 (減法)

	// 水平整合器 如 Moon

	// rewrite ... 點點點 the three point argument to one argument or with array

	// new File(), mkdirs() convert to nio.Path.get() 但是仍不完美

	// 到底先 syn 還是先 call method? // 看情況
	//
	// syn{
	//
	// checkRange(idx,0,len);
	//
	// 先 syn 後 call method 後再離開
	// syn 區塊
	//
	// }

	// Circ W Blank for JSP c314.jsp

	// Arrays.fill(charAry, '0');
	// for (int i = 0, len = charAry.length; i != len; i++)

	///////////////////////////////////////////////

	// if(obj==null) 比較快
	// 還是
	// if(int32==0) 比較快

	///////////////////////////////////////////////

	/**
	 * The power of.<br/>
	 * The power of.
	 */
	public static long pow(int base, int exp) {

		// if (exp < 0) x("exp=" + exp);

		long ans = 1L, base64 = base;

		do {
			if ((exp & 0b1) != 0b0) ans *= base64; // 第一次及最末一次才接觸 ans

			if ((exp >>>= 1) == 0b0) return ans;

			base64 *= base64; // fuck O.l("base64=" + base64);

		} while (B.T);

	}

	/**
	 * To throw RuntimeException.<br/>
	 * To throw RuntimeException.
	 */
	public static void x() {

		throw new RuntimeException();
	}

	/**
	 * To throw RuntimeException.<br/>
	 * To throw RuntimeException.
	 */
	public static void x(CharSequence charSeq) {

		throw new RuntimeException((charSeq instanceof String) ? ((String) charSeq) : charSeq.toString());
	}

	/**
	 * Is equal or not?<br/>
	 * Is equal or not?
	 */
	public static long eq(long num, long ans) {

		if (num != ans) throw new RuntimeException("num=" + num + " ans=" + ans);

		return num;

	}

	/**
	 * Is greater than or equal to?<br/>
	 * Is greater than or equal to?
	 */
	public static long gte(long num, long bound) {

		if (num < bound) throw new RuntimeException("num=" + num + " bound=" + bound);

		return num;

	}

	/**
	 * Is less than or equal to?<br/>
	 * Is less than or equal to?
	 */
	public static long lte(long num, long bound) {

		if (num > bound) throw new RuntimeException("num=" + num + " bound=" + bound);

		return num;

	}

	/**
	 * 取得現在時間 64 位元毫秒數.<br/>
	 * To return current time in millisecond.
	 */
	public static long t() {

		return System.currentTimeMillis();
	}

	/**
	 * To return the random number from 0 to less than 100
	 */
	public static int rnd100() {

		return ThreadLocalRandom.current().nextInt(800) >>> 3; // 792,793,794,795,796,797,798,799
	}

	/**
	 * 把數字轉格式化字串.<br/>
	 * To format and to string.
	 */
	public static String f(long n) {

		return String.format(REGEX_INT, n);
	}

	/**
	 * 把數字轉格式化字串.<br/>
	 * To format and to string.
	 */
	public static String f(int n) {

		return String.format(REGEX_INT, n);
	}

	/**
	 * To return 0 or 1<br/>
	 * To return 0 or 1
	 */
	public static char f(boolean b) {

		return (b ? C49 : C48);
	}
}
