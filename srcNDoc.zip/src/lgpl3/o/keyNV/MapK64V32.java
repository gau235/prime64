package lgpl3.o.keyNV;

import java.io.Serializable;

import lgpl3.o.B;
import lgpl3.o.O;
import lgpl3.o.ary.Arr;

/**
 * 問題在資料結構.<br/>
 * 因為資料結構不好, 才會想一直抓住它, 丟也丟不掉 若資料結構好, 心中的大石頭就放下了.
 *
 * @version 2023/08/18_17:30:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=MapK64V32" >src</a>
 *
 * @see MapK64V32
 *
 * @see MapKSV32
 */
public class MapK64V32 extends Arr<K64V32> implements Serializable {

	private static final Class<?> THIS = MapK64V32.class;

	private static final long serialVersionUID = B.genId32(THIS);

	/**
	 * 建構方法.<br/>
	 */
	public MapK64V32() {

		super(K64V32.class);
	}

	/**
	 * To put and count.<br/>
	 */
	public void easyPutNCount(long b64) {

		K64V32 tmp = new K64V32(b64, 1); // count, start with 1
		// O.l("easyPutNCount=" + B64W6.toStrByVCell(b64), THIS);

		if (i == 0) {

			if (i == fixedLen)

				extLen();

			arr[i++] = tmp;

			return;

		}

		K64V32 tail = arr[i - 1];

		if (tmp.k == tail.k)

			tail.v++;
		else {

			if (i == fixedLen)

				extLen();

			arr[i++] = tmp;

		}
	}

	/**
	 * To StringBuilder.<br/>
	 */
	@Override
	public StringBuilder toStr() {

		StringBuilder str = new StringBuilder(O.defLenForStr);

		for (int idx = 0; idx != i;) {

			str.append(arr[idx].toStr());

			if (++idx != i)

				str.append(O.C_A_L);

		}

		return str;

	}

	/**
	 * To StringBuilder.<br/>
	 */
	public StringBuilder toStr(CharSequence prefix, CharSequence lineWr) {

		StringBuilder str = new StringBuilder(O.defLenForStr);

		K64V32 tmpK64V32;
		for (int idx = 0; idx != i;) {

			str.append(idx + 1).append(prefix).append((tmpK64V32 = arr[idx]).k).append(O.C94).append(tmpK64V32.v);

			if (++idx != i) // todo: if (i++ != Strva.int32MaxRowForHtml)

				str.append(lineWr);

		}

		return str;

	}
}
