package lgpl3.o;

/**
 * Boole.<br/>
 * Boole.
 *
 * @version 2022/05/16_10:50:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=B" >src</a>
 *
 */
public abstract class B { // 陰陽 正負

	/**
	 * true,yes, inside.<br/>
	 */
	public static final boolean I = true;

	// [toReplace1//toReplace1]

	/**
	 * To count number of callings.<br/>
	 * To count number of callings.
	 */
	public static int cnt;

	/**
	 * 產生 ID.<br/>
	 * The create a number as ID.
	 */
	public static int genId32(Class<?> calledByWhichClass) {

		char[] cAry = calledByWhichClass.getCanonicalName().toCharArray();

		int ans = 0, idx = 0, tmpV;

		for (; idx != cAry.length;)

			ans += (tmpV = cAry[idx]) * tmpV * (++idx);

		// ans = 20;

		// [toReplace2//toReplace2]

		return ans;

	}
}