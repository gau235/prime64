package lgpl3.recycle;

import java.lang.reflect.Method;

import lgpl3.o.O;

/**
 * To cmpress.<br/>
 * To cmpress.
 *
 * @version 2023/05/21_22:00:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Zw_IntTYPE" >src</a>
 *
 */
public class Zw_IntTYPE { // 昌宏 呼叫 TYPE

	public static void main(Integer bigI) {

		O.l("Integer=" + bigI);
	}

	public static void main(int idx) {

		O.l("int=" + idx);
	}

	public static void main(String s) {
	}

	public static void main(String[] sAry) throws Throwable {

		Class<?> c = Class.forName(Zw_IntTYPE.class.getCanonicalName());

		O.l("c=" + c);

		Method m1 = c.getMethod("main", Integer.class);
		O.l("m1=" + m1);

		Method m2 = c.getMethod("main", Integer.TYPE);
		O.l("m2=" + m2);

	}
}
