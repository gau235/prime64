package lgpl3.recycle;

import static lgpl3.o.B.T;

import java.util.Arrays;

import lgpl3.o.O;
import lgpl3.o.ary.Ary32va;
import lgpl3.shuffle.Shuffler;

/**
 * Bubble Sort.<br/>
 * Bubble Sort.
 *
 * @version 2022/12/16_10:20:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Zw_BubbleSort" >src</a>
 *
 */
public class Zw_BubbleSort {

	public static int[] bubbleSort(int[] ary) {

		int iBig, j;

		boolean isSwapped;

		for (iBig = ary.length - 1; iBig > 0; iBig--) {

			O.l("iBig=" + iBig + " ary=" + Arrays.toString(ary));

			isSwapped = !T;

			for (j = 0; j < iBig; j++) {

				if (ary[j] > ary[j + 1]) {

					Ary32va.swapV(ary, j, j + 1);

					isSwapped = T;

				}

				O.lv(j + 1, "ary=" + Arrays.toString(ary));

			}

			if (!isSwapped) {

				O.l("skip it");

				return ary;

			}
		}

		return ary;

	}

	public static void main(String[] sAry) {

		int[] ary = { 10, 20, 30, 40, 50, 60 };
		int[] clonedAry = ary.clone();

		O.l("bef===");
		O.l(Shuffler.shuffle(ary));

		O.l("aft===");
		O.l(bubbleSort(ary));

		if (!Arrays.equals(ary, clonedAry))

			O.x(O.L + Arrays.toString(ary) + "=>ary" + O.L + Arrays.toString(clonedAry) + "=>clonedAry");

	}
}