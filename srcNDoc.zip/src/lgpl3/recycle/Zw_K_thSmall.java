package lgpl3.recycle;

import lgpl3.o.O;
import lgpl3.o.ary.Ary32va;
import lgpl3.shuffle.Shuffler;

/**
 * k-thSmall.<br/>
 * k-thSmall.
 *
 * @version 2022/12/26_10:20:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Zw_K_thSmall" >src</a>
 *
 */
public class Zw_K_thSmall {

	public static int k_thSmall(int[] ary, int k) {

		int left = 0, right = ary.length - 1;
		int ret;

		while (left <= right) {

			if ((ret = Ary32va.pivotIdxAftParti(ary, left, right)) == k) // O.l("in loop=");

				return ary[ret];

			if (ret > k)

				right = ret - 1;
			else
				left = ret + 1;

		}

		throw new RuntimeException();

	}

	public static void main(String[] sAry) {

		int[] ary = { 20, 30, 50, 80, 90 };

		O.l("bef===");
		O.l(ary = Shuffler.shuffle(ary));

		O.l("k_thSmall=");
		O.l(O.Z + k_thSmall(ary, 3));
		// O.l(O.Z + k_thSmall(ary, ary.length / 2));

	}
}