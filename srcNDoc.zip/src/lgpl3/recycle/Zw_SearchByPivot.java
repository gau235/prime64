package lgpl3.recycle;

import lgpl3.o.O;
import lgpl3.o.ary.Ary32va;

/**
 * Search By Pivot.<br/>
 * Search By Pivot.
 *
 * @version 2022/12/26_10:20:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Zw_SearchByPivot" >src</a>
 *
 */
public class Zw_SearchByPivot {

	/**
	 * To search.
	 */
	public static int srhByPivot(int[] ary /* unsorted */, int key, int left, int right) { // 會把資料分群並搬移

		while (left <= right) {

			int idxPivot = Ary32va.partiNRetIdxOfPivot(ary, left, right);
			int pivot = ary[idxPivot];

			if (key == pivot)

				return idxPivot;

			if (key > pivot) {

				left = idxPivot + 1;

				O.l("idxPivot=" + idxPivot + " left=" + left + " right=" + right);

			} else {

				right = idxPivot - 1;

				O.l("idxPivot=" + idxPivot + " left=" + left + " right=" + right);

			}
		}

		return -1; // not find

	}

	public static void main(String[] sAry) throws Throwable {

		int[] ary = { 30, 40, 89, 10, 60, 50 };
		int key = 89;

		O.l("ary=");
		O.l(ary);
		O.l("key=" + key);

		int foundIdx = srhByPivot(ary, key, 0, ary.length - 1);

		O.l("foundIdx=" + foundIdx);

	}
}