package lgpl3.recycle;

import static lgpl3.o.B.T;

import java.util.Scanner;

import lgpl3.o.O;

/**
 * input abcabc will output 3.<br/>
 * 找最短週期.
 *
 * @version 2022/12/13_10:20:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Zw_FindPeriod" >src</a>
 *
 */
public class Zw_FindPeriod {

	public static void main(String[] sAry) {

		Scanner sc = new Scanner(System.in);

		O.l("pleas input a string:");

		char[] cAry = sc.next().toCharArray();

		O.l("input=" + String.valueOf(cAry));

		for (int range = 1; range <= cAry.length; range++) // 假設初始跨徑為 1

			if (cAry.length % range == 0) { // 長度是跨徑的多少倍 避免當 input vvavv 卻 output 週期為 3

				boolean isConflict = !T;
				int pos = range; // position

				for (; pos < cAry.length; pos++) {

					O.l("range=" + range + " pos=" + pos + O.L + "tail=" + cAry[pos] + " head=" + cAry[pos % range]);

					if (cAry[pos] != cAry[pos % range]) { // 看後面字元有沒吻合前面字元 鋪排只為副歌

						isConflict = T;

						break;

					}
				}

				if (!isConflict) {

					O.l("period=" + range);
					break;

				}
			}
	}
}