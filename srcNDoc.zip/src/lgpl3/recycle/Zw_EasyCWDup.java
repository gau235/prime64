package lgpl3.recycle;

import lgpl3.b32.B32va;
import lgpl3.comb.b64WVCell.B64W6;
import lgpl3.comb.wDup.DatWDup;
import lgpl3.comb.wDup.thr.ThrToCWDup;
import lgpl3.o.O;
import lgpl3.o.ary.Seq;
import lgpl3.o.keyNV.KAr32V32;

/**
 * CWDup<br/>
 * CWDup
 *
 * @version 2023/09/18_23:20:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Zw_EasyCWDup" >src</a>
 *
 */
public class Zw_EasyCWDup {

	private static final Class<?> THIS = Zw_EasyCWDup.class;

	/**
	 * 從 1 列全相異數列中取出 k 個數.
	 *
	 * @see ThrToCWDup #reGo(long, long)
	 * @see B32va #next1BitL(int, int)
	 */
	public static void cWDup(final int boundBit, int rmdK, int prefix, int curBit, KAr32V32 kV) {

		// B.cnt++;

		if (--rmdK == 0) { // termination condition

			do
				kV.k[kV.v++] = (curBit | prefix);

			while ((curBit <<= 1) != boundBit);

			return;

		}

		// if you pick 3 from [A,B,C,D] then at most you can start from B as [B,C,D] not [C,D,X]
		int newBoundBit = boundBit >>> rmdK;

		// O.l("rmdK=" + rmdK + ", newBoundBit=" + B32va.str16(newBoundBit), THIS);

		do
			cWDup(boundBit, rmdK, (curBit | prefix), (curBit <<= 1), kV);

		while (curBit != newBoundBit); // while ((curBit << rmdK) <= boundBit);
		// while ((curBit << rmdK) < newBoundBit);

	}

	/**
	 * PWDup<br/>
	 */
	public static DatWDup cWDup(String s, int k) {

		DatWDup datWDup = new DatWDup();

		datWDup.oriS = s;
		datWDup.k = k;

		datWDup.initAll();

		O.l("allBit=" + O.S64 + THIS + "=" + B64W6.str24(datWDup.b64As2PowOfQRPlus1));

		Seq retSeq = new Seq();

		datWDup.tmpObj = retSeq;

		// pWDup(datWDup.b64As2PowOfQRPlus1, 0b0L, retSeq, k);

		return datWDup;

	}

	public static void main(String[] sAry) throws Throwable {

		String myS = "Y,B,B,C,C,C";

		int k = 3;

	}
}