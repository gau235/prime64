package lgpl3.recycle;

import java.util.Arrays;

import lgpl3.o.O;

/**
 * Merge sort.<br/>
 *
 * @version 2023/06/26_10:20:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Zw_MergeSort" >src</a>
 *
 */
public class Zw_MergeSort {

	static void merge(int[] ar, int left, int mid, int right) {

		O.l("left=" + left + " mid=" + mid + " right=" + right);

		int[] tmpAr = new int[ar.length]; // 缺點 copy all

		for (int i = left; i <= right;) // copy array to tmp array

			tmpAr[i] = ar[i++];

		// merge array[left...mid] and array[mid + 1...right]
		int goL = left, goR = mid + 1;

		for (int i = left; i <= right;)

			if (goL > mid) // 左邊過頭了

				ar[i++] = tmpAr[goR++];

			else if (goR > right) // 右邊過頭了

				ar[i++] = tmpAr[goL++];

			else if (tmpAr[goL] > tmpAr[goR])

				ar[i++] = tmpAr[goR++];
			else
				ar[i++] = tmpAr[goL++];

	}

	static void mgSort(int[] ar, int left, int right) {

		if (left >= right)

			return;

		int mid = left + (right - left) / 2;

		// 切割 切割 後合併
		mgSort(ar, left, mid);

		mgSort(ar, mid + 1, right);

		merge(ar, left, mid, right);

	}

	public static void main(String[] sAry) throws Throwable {

		int[] ary = { 30, 89, 40, 10, 60, 50, -40 }, clonedAry = ary.clone();

		Arrays.sort(clonedAry);

		O.l("bef=" + O.L + Arrays.toString(ary));

		mgSort(ary, 0, ary.length - 1); // merge sort 切割 切割 後合併

		if (!Arrays.equals(ary, clonedAry))

			O.x(O.L + Arrays.toString(ary) + "=>ary" + O.L + Arrays.toString(clonedAry) + "=>clonedAry");

		O.l("aft=" + O.L + Arrays.toString(ary));

	}
}