package lgpl3.recycle;

import static java.lang.System.out;

import lgpl3.o.O;

/**
 * @version 2023/10/18_40:00:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Zw_EasyMatrixMul" >src</a>
 *
 */
public class Zw_EasyMatrixMul { // 矩陣相乘

	static int x = 2;
	static int y = 3;
	static int z = 2;

	public static void main(String[] sAry) {

		int[][] A = new int[x][y], B = new int[y][z];

		int[][] C = new int[x][z];

		A[0] = new int[] { 1, 2, 3 };
		A[1] = new int[] { 4, 5, 6 };

		B[0] = new int[] { 1, 2 };
		B[1] = new int[] { 3, 4 };
		B[2] = new int[] { 5, 6 };

		int ix, iz, iy;

		for (ix = 0; ix < x; ix++) {

			for (iz = 0; iz < z; iz++) {

				for (iy = 0; iy < y; iy++)

					C[ix][iz] += A[ix][iy] * B[iy][iz]; // 陣列 A 乘以陣列 B, 存入陣列 C

				out.print(C[ix][iz] + " ");

			}

			O.l();

		}
	}
}
