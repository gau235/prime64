package lgpl3.recycle;

import static java.lang.System.out;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

import lgpl3.o.B;
import lgpl3.o.O;

/**
 * P<br/>
 * P
 *
 * @version 2022/12/16_10:20:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Zw_PWDup" >src</a>
 *
 */
public class Zw_PWDup {

	static ArrayList<Integer> base = new ArrayList<Integer>(Arrays.asList(20, 10, 10, 20, 20, 20, 20, 30, 30));

	static int k = 3;

	public static ArrayList<Integer> dif(ArrayList<Integer> list, ArrayList<Integer> ex) {

		ArrayList<Integer> ret = (ArrayList<Integer>) list.clone();

		for (Integer iObj : ex)

			ret.remove(iObj);

		return ret;

	}

	public static void p(ArrayList<Integer> list, int lv) {

		++lv;

		ArrayList<Integer> rmdList = dif(base, list), cache = new ArrayList<Integer>();

		if (list.size() + 1 == k) {

			for (int i = 0, size = rmdList.size(); i != size;) {

				ArrayList<Integer> clonedList = (ArrayList<Integer>) list.clone();
				clonedList.add(rmdList.get(i));

				if (i++ == 0) {

					cache = clonedList;
					O.lv(lv, "fin i==0 " + clonedList.toString());
					B.cnt++;

				} else if (clonedList.equals(cache))

					out.print(""); // O.lv(lv, "fin xxxx=" + cache.toString() + " clonedList=" + clonedList.toString());
				else {

					// O.lv(lv, "fin cache=" + cache.toString() + " clonedList=" + clonedList.toString());

					cache = clonedList;

					// O.lv(lv, "fin newCache=" + cache.toString());

					O.lv(lv, "fin=" + clonedList.toString());
					B.cnt++;

				}
			}

			return;

		}

		for (int i = 0, size = rmdList.size(); i != size;) {

			ArrayList<Integer> clonedList = (ArrayList<Integer>) list.clone();
			clonedList.add(rmdList.get(i));

			if (i++ == 0)

				p(cache = clonedList, lv); // O.lv(lv, "i==0");

			else if (clonedList.equals(cache))

				out.print(""); // O.lv(lv, "xxxx=" + cache.toString() + " clonedList=" + clonedList.toString());
			else {

				// O.lv(lv, "cache=" + cache.toString() + " clonedList=" + clonedList.toString());

				cache = clonedList;

				// O.lv(lv, "newCache=" + cache.toString());

				p(clonedList, lv);

			}
		}
	}

	public static void main1(String[] sAry) {

		ArrayList<String> list1 = new ArrayList<String>();
		ArrayList<String> list2 = new ArrayList<String>();

		list1.add("10");
		list1.add("20");

		list2.add("10");
		list2.add("20");

		if (list1.equals(list2))

			O.l("==equal");

	}

	public static void main2(String[] sAry) {

		ArrayList<Integer> list1 = new ArrayList<Integer>(Arrays.asList(1, 2, 3));
		ArrayList<Integer> list2 = new ArrayList<Integer>(Arrays.asList(1, 3));

		ArrayList<Integer> rmdList = dif(list1, list2);

		O.l("list1=" + list1.toString() + " rmdList=" + rmdList.toString());

	}

	public static void main(String[] sAry) {

		Collections.sort(base);

		O.l("base=" + base.toString());

		p(new ArrayList<Integer>(), 0);

		O.l("cnt=" + B.cnt);

		B.cnt = 0;

	}
}