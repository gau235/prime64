package lgpl3.recycle;

import java.util.Arrays;

import lgpl3.o.O;
import lgpl3.o.ary.Ary32va;
import lgpl3.shuffle.Shuffler;

/**
 * Stooge Sort.<br/>
 * Stooge Sort.
 *
 * @version 2022/12/16_10:20:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Zw_StoogeSort" >src</a>
 *
 */
public class Zw_StoogeSort {

	public static int[] stoogeSort(int[] ary32, int low, int high) {

		if (ary32[low] > ary32[high])

			Ary32va.swapV(ary32, low, high);

		if (low + 1 >= high)

			return ary32;

		int idx1_3 = (high - low + 1) / 3;

		stoogeSort(ary32, low, (high - idx1_3));
		stoogeSort(ary32, (low + idx1_3), high);
		stoogeSort(ary32, low, (high - idx1_3));

		return ary32;

	}

	public static void main(String[] sAry) {

		int[] ary = { 10, 20, 30, 40, 50, 60 };
		int[] clonedAry = ary.clone();

		O.l("bef===");
		O.l(Shuffler.shuffle(ary));

		O.l("aft===");
		O.l(stoogeSort(ary, 0, ary.length - 1));

		if (!Arrays.equals(ary, clonedAry))

			O.x(O.L + Arrays.toString(ary) + "=>ary" + O.L + Arrays.toString(clonedAry) + "=>clonedAry");

	}
}