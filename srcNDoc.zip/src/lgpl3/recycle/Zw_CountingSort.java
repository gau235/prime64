package lgpl3.recycle;

import java.util.Arrays;

import lgpl3.o.O;
import lgpl3.o.ary.Ary32va;
import lgpl3.shuffle.Shuffler;

/**
 * 計數排序法 (Distributive Counting Sort)<br/>
 *
 * @version 2023/10/15_21:20:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Zw_CountingSort" >src</a>
 *
 */
public class Zw_CountingSort {

	public static int[] distributiveCountingSort(int[] ar) {

		int minNMax[] = Ary32va.findMinMax(ar), min = minNMax[0], max = minNMax[1];

		O.l("min=" + min);

		int[] qtyAr = new int[max - min + 1];

		int idx, qty;
		for (idx = 0; idx < ar.length; idx++) {

			qty = ar[idx] - min; // 事後該把 qtyAr 的索引加上 min 加回去
			qtyAr[qty]++;

		}

		O.l("qtyAr=" + O.L + Arrays.toString(qtyAr));

		for (int iQty = idx = 0; iQty < qtyAr.length; iQty++) {

			qty = qtyAr[iQty];

			if (qty > 0) { // 個數值不為 0 , 才需填入

				O.l("idx=" + idx + " iQty=" + iQty + " qty=" + qty);

				for (; qty-- > 0; idx++) { // 重複地填入

					ar[idx] = (iQty + min);

					O.l("填入 " + (iQty + min));

				}
			}
		}

		return ar;

	}

	public static void main(String[] sAry) {

		int[] ar = { 3, 5, 6, 6, 9 }, clonedAr = ar.clone();

		ar = Shuffler.shuffle(ar);

		O.l("bef=" + O.L + Arrays.toString(ar));

		O.l("aft=" + O.L + Arrays.toString(distributiveCountingSort(ar)));

		if (!Arrays.equals(ar, clonedAr))

			O.x(O.L + Arrays.toString(ar) + "=>ar" + O.L + Arrays.toString(clonedAr) + "=>clonedAr");

	}
}