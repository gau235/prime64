package lgpl3.recycle;

import java.util.Arrays;

import lgpl3.o.O;
import lgpl3.o.ary.Ary32va;
import lgpl3.shuffle.Shuffler;

/**
 * 計數排序法(Counting Sort)<br/>
 *
 * 舉例來說，已知序列中的元素均為 1, 2, 3, 4 的其中一個數值。<br/>
 * 這個序列中實際儲存的資料為[3, 2, 1, 2, 3, 3, 1]，<br/>
 * 我們可以先計算出這個序列共有2個1、2個2、3個3、和0個4。<br/>
 *
 * 接著就開始把數值依序填進這個相同的序列中，首先填入2個1，<br/>
 * 序列內容會變成[1, 1, 1, 2, 3, 3, 1]。<br/>
 * 再來填入2個2，序列內容會變成[1, 1, 2, 2, 3, 3, 1]。<br/>
 * 再來填入3個3，序列內容會變成[1, 1, 2, 2, 3, 3, 3]。<br/>
 * 最後的4由於原先就沒有出現，所以不用填寫，此時就完成這個序列的排序了。
 *
 * @version 2022/12/16_10:20:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Zw_CountingSort" >src</a>
 *
 */
public class Zw_CountingSort {

	public static int[] countingSort(int[] ary) {

		int minNMax[] = Ary32va.findMinMax(ary), min = minNMax[0], max = minNMax[1];

		int[] qtyAry = new int[max - min + 1];

		int i;
		for (i = 0; i < ary.length; i++)

			qtyAry[ary[i] - min]++; // 簡便寫法 // 事後若 count[i]=5 還要加上 min 當成位移多少

		O.l("qtyAry===");
		O.l(qtyAry);
		O.l("===");

		i = 0;

		for (int idxQ = 0; idxQ < qtyAry.length; idxQ++) {

			int v = min + idxQ; // 加上 min 位移多少

			for (int qty = qtyAry[idxQ]; qty > 0; qty--) // 有幾個就填入 填滿

				ary[i++] = v;

			if (i == ary.length)

				break;

		}

		return ary;

	}

	public static void main(String[] sAry) {

		int[] ary = { 1, 3, 6, 6, 9 };
		int[] clonedAry = ary.clone();

		O.l("bef===");
		O.l(Shuffler.shuffle(ary));

		O.l("aft===");
		O.l(countingSort(ary));

		if (!Arrays.equals(ary, clonedAry))

			O.x(O.L + Arrays.toString(ary) + "=>ary" + O.L + Arrays.toString(clonedAry) + "=>clonedAry");

	}
}