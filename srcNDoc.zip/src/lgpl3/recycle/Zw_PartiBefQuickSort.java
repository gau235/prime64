package lgpl3.recycle;

import java.util.Arrays;

import lgpl3.o.O;
import lgpl3.o.ary.Ary32va;
import lgpl3.shuffle.Shuffler;

/**
 * Bubble Sort.<br/>
 * Bubble Sort.
 *
 * @version 2022/12/16_10:20:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Zw_PartiBefQuickSort" >src</a>
 *
 */
public class Zw_PartiBefQuickSort {

	public static int k_thSmall(int[] ary, int k) {

		int left = 0, right = ary.length - 1;
		int ret;

		while (left <= right) {

			if ((ret = Ary32va.pivotIdxAftParti(ary, left, right)) == k) // O.l("in loop=");

				return ary[ret];

			if (ret > k)

				right = ret - 1;
			else
				left = ret + 1;

		}

		throw new RuntimeException();

	}

	public static int[] quickSort(int[] ary, int left, int right) {

		if (left <= right) {

			int idxPivot = Ary32va.pivotIdxAftParti(ary, left, right);

			quickSort(ary, left, idxPivot - 1);

			quickSort(ary, idxPivot + 1, right);

		}

		return ary;

	}

	public static void main(String[] sAry) {

		int[] ary = { 20, 30, 50, 80, 90 };
		int[] clonedAry = ary.clone();

		O.l("bef===");
		O.l(ary = Shuffler.shuffle(ary));

		int pivotIdx = Ary32va.pivotIdxAftParti(ary, 0, ary.length - 1);

		O.l("pivot=ary[" + pivotIdx + "]=" + ary[pivotIdx]);

		O.l("quickSort===");
		O.l(quickSort(ary, 0, ary.length - 1));

		if (!Arrays.equals(ary, clonedAry))

			O.x(O.L + Arrays.toString(ary) + "=>ary" + O.L + Arrays.toString(clonedAry) + "=>clonedAry");

	}

	public static void main2(String[] sAry) {

		int[] ary = { 20, 30, 50, 80, 90 };

		O.l("bef===");
		O.l(ary = Shuffler.shuffle(ary));

		O.l("k_thSmall=");
		O.l(O.Z + k_thSmall(ary, 3));
		// O.l(O.Z + k_thSmall(ary, ary.length / 2));

	}
}