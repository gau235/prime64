package lgpl3.recycle;

import static java.lang.System.out;

/**
 * IEEE-754 float.<br/>
 * IEEE-754 float.
 *
 * @version 2022/12/16_10:20:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Zw_Ieee754Float" >src</a>
 *
 */
public class Zw_Ieee754Float {

	public static void main(String[] sAry) throws Throwable { // 左至右 第 31 位到第 0 位

		float flo = -22.5F;

		int b32 = Float.floatToIntBits(flo);

		for (int i = 31; i >= 0; i--) {

			if (i == 30 || i == 26 || i == 22 || i == 18)

				out.print("_");

			out.print((b32 & (0b1 << i)) == 0 ? "0" : "1");

		}
	}
}