package lgpl3.recycle;

import lgpl3.o.O;
import lgpl3.o.str.SW;

/**
 * IEEE-754 float.<br/>
 * IEEE-754 float.
 *
 * @version 2023/01/10_10:20:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Zw_Ieee754Float" >src</a>
 *
 */
public class Zw_Ieee754Float {

	public static void main(String[] sAry) throws Throwable { // 左至右 第 31 位到第 0 位

		float inputF = 221.625F; // 0_1000_0110_1011_1011_010000000000000

		int b32 = Float.floatToIntBits(inputF);

		SW ans = new SW();

		for (int i = 31; i >= 0; i--) {

			if (i == 30 || i == 22 || i == 14 || i == 6) ans.a("_");

			ans.a((b32 & (0b1 << i)) == 0 ? "0" : "1");

		}

		O.l(ans.str);

	}
}