package lgpl3.recycle;

import static lgpl3.comb.b64WVCell.B64W6BitPerCellFromR.$6;

import lgpl3.b32.B32va;
import lgpl3.comb.b64WVCell.B64W6;
import lgpl3.o.B;
import lgpl3.o.O;
import lgpl3.o.ary.Ary32va;

/**
 * To cmpress.<br/>
 * To cmpress.
 *
 * @version 2023/05/21_22:00:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Zw_BitRow" >src</a>
 *
 */
public class Zw_BitRow {

	public int k;

	public long vToIdxB64W6;

	public int[] bitRow;

	/**
	 * 0b_10_8_5 => 0b_3_0_2_0_0_1_0_0_0_0
	 */
	public static long vToIdxNCompress(long sortedB64) {

		long order = 1L;
		long ret = 0b0L;

		int qty;
		do {
			qty = ((int) sortedB64) & B64W6.MASK32;

			// O.l("qty=" + qty);

			ret |= (order++ << ((qty - 1) * $6));

		} while (((int) (sortedB64 >>>= $6)) != 0b0);

		// O.gte(ret, 1);

		return ret;

	}

	public static long countOffset(long b64W6, int radix) {

		// O.l("getOffset B64W6=" + O.L + B64W6.str(b64W6));

		long ret = 0L;

		int qty, x = 1;
		do {
			qty = ((((int) b64W6) & B64W6.MASK32) - 1);

			// O.l("getOffset qty=" + qty);

			ret += qty * x;

			// O.l("getOffset ret=" + ret);

			x *= radix;

		} while (((int) (b64W6 >>>= $6)) != 0b0); // b64W6 不會在兩 cell 之間有空的 cell

		// O.gte(ret, 1);

		return ret;

	}

	public Zw_BitRow(int k, long b64W6AftC) {

		this.k = k;

		vToIdxB64W6 = vToIdxNCompress(B64W6.easySort(b64W6AftC, k));

		// O.l("vToIdxB64W6=" + O.L + B64W6.str(vToIdxB64W6));

		long b64ForLen = B64W6.genB64W6ByAry32(Ary32va.genAscAry32From1(k));

		b64ForLen >>>= $6; // fuck

		// O.l("b64ForLen" + O.L + B64W6.str(b64ForLen));

		b64ForLen = countOffset(b64ForLen, k);

		bitRow = new int[((int) (b64ForLen >>> 5)) + 1];

		// O.l("bitRow.len=" + O.f(bitRow.length));

	}

	/**
	 * 0b_10_8_5 => 0b_3_0_2_0_0_1_0_0_0_0
	 */
	public long simplify(long b64W6) {

		// O.l("simplify B64W6=" + O.L + B64W6.str(b64W6));

		long ret = 0b0L;

		int v;
		do {
			v = ((int) b64W6) & B64W6.MASK32;

			// O.l("v=" + v);

			ret |= (vToIdxB64W6 >>> ((v - 1) * $6)) & B64W6.MASK32;

			// O.l("simplify ret=" + O.L + B64W6.str(ret));

			if ((((int) (b64W6 >>>= $6)) == 0b0))

				return ret;

			ret <<= $6;

		} while (B.T); // b64W6 不會在兩 cell 之間有空的 cell

	}

	/**
	 * putIfAbsent
	 */
	public boolean putIfAbsent(long b64W6) {

		// O.l("putIfAbsent B64W6=" + O.L + B64W6.str(b64W6));

		long offset = countOffset(simplify(b64W6 >>> $6), k);

		// O.l("putIfAbsent countOffset=" + offset);

		int big = (int) (offset >>> 5);
		int small = ((int) (offset)) & 0b1_1111;

		int oneOrZero = bitRow[big] >>> (small - 1);

		if ((oneOrZero & 0b1) == 0b0) { // not exist

			bitRow[big] |= 0b1 << (small - 1); // put

			return B.T;

		}

		return !B.T; // exist

	}

	public static void main(String[] sAry) throws Throwable {

		int n = 8;
		int k = 3;

		long b64W6 = B64W6.genB64W6ByAry32(8, 2, 1);

		int b32 = B64W6.toB32As2PowByB6Cell(b64W6);

		O.l("b32=" + B32va.str(b32));

		O.l("B64W6=" + O.L + B64W6.str(b64W6));

		Zw_BitRow filter = new Zw_BitRow(k, b32);

		O.l("putIfAbsent=" + O.f(filter.putIfAbsent(b64W6)));

		O.l("putIfAbsent=" + O.f(filter.putIfAbsent(B64W6.genB64W6ByAry32(1, 8, 2))));

		for (int i = 0; i != filter.bitRow.length; i++)

			O.l("i=" + i + O.L + B32va.str(filter.bitRow[i]));

	}
}
