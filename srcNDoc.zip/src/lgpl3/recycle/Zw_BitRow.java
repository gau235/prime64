package lgpl3.recycle;

import lgpl3.b32.B32va;
import lgpl3.comb.b64WVCell.B64W6;
import lgpl3.o.B;
import lgpl3.o.O;

/**
 * To cmpress.<br/>
 * To cmpress.
 *
 * @version 2023/05/21_22:00:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Zw_BitRow" >src</a>
 *
 */
public class Zw_BitRow {

	public int n;
	public int k;

	public int b32AftC;

	public long vToIdxB64W6;

	public int[] bitRow;

	public Zw_BitRow(int n, int k, int b32AftC) {

		this.n = n;

		this.k = k;

		this.b32AftC = b32AftC;

		vToIdxB64W6 = B64W6.vToIdxNCompress(b32AftC);

		O.l("vToIdxB64W6=" + O.L + B64W6.str(vToIdxB64W6));

		bitRow = new int[(int) (O.pow(k, k - 1) >>> 5) + 1];

		O.l("bitRow.len=" + bitRow.length);

	}

	/**
	 * 0b_10_8_5 => 0b_3_0_2_0_0_1_0_0_0_0
	 */
	public long simplify(long b64W6) {

		O.l("simplify B64W6=" + O.L + B64W6.str(b64W6));

		long ret = 0b0L;

		int v;
		do {
			v = ((int) b64W6) & B64W6.MASK32;

			O.l("v=" + v);

			ret |= (vToIdxB64W6 >>> ((v - 1) * B64W6.$6)) & B64W6.MASK32;

			O.l("simplify ret=" + O.L + B64W6.str(ret));

			if ((((int) (b64W6 >>>= B64W6.$6)) == 0b0))

				return ret;

			ret <<= B64W6.$6;

		} while (B.T); // b64W6 不會在兩 cell 之間有空的 cell

	}

	public int getOffset(long b64W6) {

		O.l("getOffset B64W6=" + O.L + B64W6.str(b64W6));

		int ret = 0, v, base = 1;
		do {
			v = ((((int) b64W6) & B64W6.MASK32) - 1);

			O.l("getOffset v=" + v);

			ret += v * base;

			O.l("getOffset ret=" + ret);

			base *= k;

		} while (((int) (b64W6 >>>= B64W6.$6)) != 0b0); // b64W6 不會在兩 cell 之間有空的 cell

		return ret;

	}

	public boolean putIfAbsent(long b64W6) {

		O.l("putIfAbsent B64W6=" + O.L + B64W6.str(b64W6));

		int offset = getOffset(simplify(b64W6 >>> B64W6.$6));

		O.l("offset=" + offset);

		int big = offset >>> 5;
		int small = offset & 0b1_1111;

		int v = bitRow[big];
		v >>>= (small - 1);

		if ((v & 0b1) == 0b0) { // not exist

			bitRow[big] |= 0b1 << (small - 1); // put

			return B.T;

		}

		return !B.T; // exist

	}

	public static void main(String[] sAry) throws Throwable {

		int n = 8;
		int k = 3;

		long b64W6 = B64W6.genB64W6ByAry32(8, 2, 1);

		int b32 = B64W6.toB32As2PowByB6Cell(b64W6);

		O.l("b32=" + B32va.str(b32));

		O.l("B64W6=" + O.L + B64W6.str(b64W6));

		Zw_BitRow filter = new Zw_BitRow(n, k, b32);

		O.l("putIfAbsent=" + O.f(filter.putIfAbsent(b64W6)));

		O.l("putIfAbsent=" + O.f(filter.putIfAbsent(B64W6.genB64W6ByAry32(1, 8, 2))));

		for (int i = 0; i != filter.bitRow.length; i++)

			O.l("i=" + i + O.L + B32va.str(filter.bitRow[i]));

	}
}
