package lgpl3.recycle;

import java.util.Arrays;

import lgpl3.o.O;
import lgpl3.o.ary.Ary32va;
import lgpl3.shuffle.Shuffler;

/**
 * QuickSort.<br/>
 * QuickSort.
 *
 * @version 2022/12/16_10:20:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Zw_QuickSort" >src</a>
 *
 */
public class Zw_QuickSort {

	public static int[] quickSort(int[] ary, int left, int right) {

		if (left < right) {

			int iPivot = Ary32va.partiNRetIdxOfPivot(ary, left, right);

			quickSort(ary, left, iPivot - 1);

			quickSort(ary, iPivot + 1, right);

		}

		return ary;

	}

	public static void main1(String[] sAry) {

		int[] ary = { 50, 90, 70, 20, 10, 30 };

		O.l("bef===");
		O.l(Arrays.toString(ary));

		int iPivot = Ary32va.partiNRetIdxOfPivot(ary, 0, ary.length - 1);

		O.l("aft pivot=ary[" + iPivot + "]=" + ary[iPivot]);

	}

	public static void main(String[] sAry) {

		int[] ary = { 50, 90, 70, 20, 10, 30 };
		int[] clonedAry = ary.clone();

		Arrays.sort(clonedAry);

		O.l("bef quickSort=");
		O.l(Arrays.toString(ary = Shuffler.shuffle(ary)));

		quickSort(ary, 0, ary.length - 1);

		O.l("aft quickSort=");
		O.l(Arrays.toString(ary));

		if (!Arrays.equals(ary, clonedAry))

			O.x(O.L + Arrays.toString(ary) + "=>ary" + O.L + Arrays.toString(clonedAry) + "=>clonedAry");

	}
}
