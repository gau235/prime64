package lgpl3.recycle;

import java.util.Arrays;

import lgpl3.o.O;
import lgpl3.o.ary.Ary32va;
import lgpl3.shuffle.Shuffler;

/**
 * QuickSort.<br/>
 * QuickSort.
 *
 * @version 2022/12/16_10:20:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Zw_QuickSort" >src</a>
 *
 */
public class Zw_QuickSort {

	public static int[] quickSort(int[] ary, int left, int right) {

		if (left < right) {

			int iPivot = Ary32va.easyPartiNRetIdxOfPivot(ary, left, right);
			// int iPivot = Ary32va.partiNRetIdxOfPivot(ary, left, right);

			quickSort(ary, left, iPivot - 1);

			quickSort(ary, iPivot + 1, right);

		}

		return ary;

	}

	public static void main(String[] sAry) {

		int[] ar = { 50, 90, 70, 20, 10, 30 };

		ar = Shuffler.shuffle(ar);

		O.l("bef=");
		O.l(Arrays.toString(ar));

		int iPivot = Ary32va.partiNRetIdxOfPivot(ar, 0, ar.length - 1);

		O.l("aft pivot=ar[" + iPivot + "]=" + ar[iPivot]);

	}

	public static void main2(String[] sAry) {

		int[] ar = { 50, 90, 70, 20, 10, 30 };
		int[] ansAr = ar.clone();

		ar = Shuffler.shuffle(ar);

		Arrays.sort(ansAr);

		O.l("bef quickSort=");
		O.l(Arrays.toString(ar));

		O.l("aft quickSort=");
		O.l(Arrays.toString(quickSort(ar, 0, ar.length - 1)));

		if (!Arrays.equals(ar, ansAr)) O.x(O.L + "ar=" + Arrays.toString(ar) + O.L + "ansAr=" + Arrays.toString(ansAr));

	}
}
