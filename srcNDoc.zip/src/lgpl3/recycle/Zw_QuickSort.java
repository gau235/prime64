package lgpl3.recycle;

import java.util.Arrays;

import lgpl3.o.O;
import lgpl3.o.ary.Ary32va;
import lgpl3.shuffle.Shuffler;

/**
 * QuickSort.<br/>
 * QuickSort.
 *
 * @version 2022/12/16_10:20:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Zw_QuickSort" >src</a>
 *
 */
public class Zw_QuickSort {

	public static int[] quickSort(int[] ary, int left, int right) {

		if (left <= right) {

			int idxPivot = Ary32va.pivotIdxAftParti(ary, left, right);

			quickSort(ary, left, idxPivot - 1);

			quickSort(ary, idxPivot + 1, right);

		}

		return ary;

	}

	public static void main(String[] sAry) {

		int[] ary = { 20, 30, 50, 80, 90 };
		int[] clonedAry = ary.clone();

		O.l("bef===");
		O.l(ary = Shuffler.shuffle(ary));

		int pivotIdx = Ary32va.pivotIdxAftParti(ary, 0, ary.length - 1);

		O.l("pivot=ary[" + pivotIdx + "]=" + ary[pivotIdx]);

		O.l("quickSort===");
		O.l(quickSort(ary, 0, ary.length - 1));

		if (!Arrays.equals(ary, clonedAry))

			O.x(O.L + Arrays.toString(ary) + "=>ary" + O.L + Arrays.toString(clonedAry) + "=>clonedAry");

	}
}
