package lgpl3.recycle;

import java.util.Arrays;

import lgpl3.o.O;

/**
 * Search By Pivot.<br/>
 * Search By Pivot.
 *
 * @version 2022/12/26_10:20:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Zw_MergeSort_Old" >src</a>
 *
 */
public class Zw_MergeSort_Old {

	public static int[] merge(int[] ary, int left, int mid, int right, int[] tmpAry, int lv) {

		O.lv(lv, "ary=" + Arrays.toString(ary));
		O.lv(lv, "left=" + left + " mid=" + mid + " right=" + right);

		int iA = left; // 初始化i, 左邊有序序列的初始索引
		int iB = mid + 1; // 初始化j, 右邊有序序列的初始索引
		int iTmp = 0;

		int[] lAry = Arrays.copyOfRange(ary, left, mid + 1 /* exclusive */);
		int[] rAry = Arrays.copyOfRange(ary, mid + 1, right + 1 /* exclusive */);

		O.lv(lv, "lAry=" + Arrays.toString(lAry) + " rAry=" + Arrays.toString(rAry));

		// 左右比大小, 將小的放到 tmp 陣列
		while (iA <= mid && iB <= right)

			if (ary[iA] <= ary[iB])

				tmpAry[iTmp++] = ary[iA++];
			else
				tmpAry[iTmp++] = ary[iB++];

		O.lv(lv, "左右比大小=" + Arrays.toString(tmpAry));

		while (iA <= mid) {

			tmpAry[iTmp++] = ary[iA++];

			O.lv(lv, "左有剩=" + Arrays.toString(tmpAry));

		}

		while (iB <= right) {

			tmpAry[iTmp++] = ary[iB++];

			O.lv(lv, "右有剩=" + Arrays.toString(tmpAry));

		}

		O.lv(lv, "tmpAry=" + Arrays.toString(tmpAry));

		// 把 tmp 陣列的片段 writeBack 到 ary
		int myLeft = left;
		for (iTmp = 0; left <= right;)

			ary[left++] = tmpAry[iTmp++];

		O.lv(lv, "writeBack from " + myLeft + "=" + Arrays.toString(ary));

		Arrays.fill(tmpAry, 0); // reset

		return ary;

	}

	public static int[] parti(int[] ary, int left, int right, int[] tmpAry, int lv) { // divide and conquer

		lv++;

		if (left >= right)

			return ary;

		int mid = (left + right) / 2;

		// 切割 切割 後合併
		parti(ary, left, mid, tmpAry, lv); // 向左遞迴進行分解

		parti(ary, mid + 1, right, tmpAry, lv); // 向右遞迴進行分解

		return merge(ary, left, mid, right, tmpAry, lv);

	}

	public static void main(String[] sAry) throws Throwable {

		int[] ary = { 30, 89, 40, 10, 60, 50, -40 }, clonedAry = ary.clone();

		Arrays.sort(clonedAry);

		O.l("bef=" + O.L + Arrays.toString(ary));

		parti(ary, 0, ary.length - 1, new int[ary.length], 0);

		if (!Arrays.equals(ary, clonedAry))

			O.x(O.L + Arrays.toString(ary) + "=>ary" + O.L + Arrays.toString(clonedAry) + "=>clonedAry");

		O.l("aft=" + O.L + Arrays.toString(ary));

	}
}