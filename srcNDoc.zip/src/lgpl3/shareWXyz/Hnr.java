package lgpl3.shareWXyz;

/**
 * 即 n 個相同物品分成給 k 人, 每人最少 1 個.<br/>
 * To return the number of ways to share several identical items with every person.
 *
 * @version 2018/11/27_21:40:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Hnr" >Hnr.java</a>
 *
 * @see Hxy
 */
public abstract class Hnr extends Hnr_U {

	// private static final Class<?> THIS = Hnr.class;

}
