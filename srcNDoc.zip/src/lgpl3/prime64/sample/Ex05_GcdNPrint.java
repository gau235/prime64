package lgpl3.prime64.sample;

import lgpl3.o.B;
import lgpl3.o.O;
import lgpl3.prime64.Miner;

/**
 * To get the GCD then to print.<br/>
 * To get the GCD then to print.
 *
 * @version 2022/05/17_10:50:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Ex05_GcdNPrint" >Ex05_GcdNPrint.java</a>
 *
 */
public class Ex05_GcdNPrint {

	public static void main(String[] sAry) {

		O.isDev = !B.I;

		Miner.gcdNPrint(512, 64);

	}
}
