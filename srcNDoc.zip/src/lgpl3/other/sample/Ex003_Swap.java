package lgpl3.other.sample;

import lgpl3.o.O;

/**
 * To swap.<br/>
 * To swap.
 *
 * @version 2022/12/05_18:40:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Ex003_Swap" >src</a>
 *
 */
public class Ex003_Swap {

	public static void swap(int a, int b) {

		int tmp = a;
		a = b;
		b = tmp;

		O.l("swap a=" + a + " b=" + b);

	}

	public static void swapByXor(int a, int b) {

		a = a ^ b;
		b = a ^ b;
		a = a ^ b;

		O.l("swapByXor a=" + a + " b=" + b);

	}

	public static void swapByAdd(int a, int b) {

		a = a + b;
		b = a - b;
		a = a - b;

		O.l("swapByAdd a=" + a + " b=" + b);

	}

	public static void swapByMul(int a, int b) {

		a = a * b;
		b = a / b;
		a = a / b;

		O.l("swapByMul a=" + a + " b=" + b);

	}

	public static void main(String[] sAry) {

		int a = 11;
		int b = 22;

		// O.l("bef a=" + a + " b=" + b);
		// swap(a, b);

		O.l("bef a=" + a + " b=" + b);
		swapByXor(a, b);

		// O.l("bef a=" + a + " b=" + b);
		// swapByAdd(a, b);

		// O.l("bef a=" + a + " b=" + b);
		// swapByMul(a, b);

	}
}
