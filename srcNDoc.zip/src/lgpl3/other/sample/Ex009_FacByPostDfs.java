package lgpl3.other.sample;

import lgpl3.o.B;
import lgpl3.o.O;

/**
 * To test.<br/>
 * 土法煉鋼.
 *
 * @version 2023/04/11_21:40:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Ex009_FacByPostDfs" >src</a>
 *
 * @see Ex010_FacByCount
 */
public class Ex009_FacByPostDfs {

	public static void facRecur(int n) {

		if (n == 1) { // usually be skipped

			B.cnt++;

			O.l("cnt=" + B.cnt);

			return;

		}

		for (int i = 1; i <= n; i++)

			facRecur(n - 1);

	}

	public static void main(String[] sAry) throws Throwable {

		int n = 4;

		facRecur(n);

		O.l("fac(" + n + ")=" + B.cnt);

		B.cnt = 0;

	}
}
