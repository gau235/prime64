package lgpl3.other.sample;

/**
 * For Linux.<br/>
 * For Linux.
 *
 * @version 2022/05/17_10:50:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Ex144_ForLinux" >Ex144_ForLinux.java</a>
 *
 */
public class Ex144_ForLinux {

	// chmod a+x ./DIY.sh

	// cd /opt/prime64Lgpl3/src
	// export JAVA_HOME=/opt/jdk
	// export PATH=/opt/jdk/bin:$PATH
	// javac -encoding UTF-8 -cp .:*:./lib/:./lib/* other/uI/Main.java
	// java -cp .:*:./lib/:./lib/* other/uI/Main

}
