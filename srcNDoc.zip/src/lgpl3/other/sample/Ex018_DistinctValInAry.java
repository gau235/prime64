package lgpl3.other.sample;

import java.util.Arrays;

import lgpl3.o.O;
import lgpl3.o.ary.Aryva;

/**
 * To distinct.<br/>
 * To distinct.
 *
 * @version 2022/10/11_09:50:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Ex018_DistinctValInAry" >src</a>
 *
 */
public class Ex018_DistinctValInAry {

	public static void main(String[] sAry) throws Throwable {

		long[] ary = { 10, 80, 20, 49, 40, 40, 40, 50, 50 };

		Arrays.sort(ary);

		O.l("easyDistinct=");
		O.l(Aryva.easyDistinct(ary));

	}

	public static void main2(String[] sAry) throws Throwable {

		long[] ary = { 10, 10, 20, 40, 40, 40, 45, 50, 50 };

		Arrays.sort(ary);

		O.l("distinctAry=");
		O.l(Aryva.distinct(ary));

	}
}