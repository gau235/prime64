package lgpl3.other.sample;

import java.util.Arrays;

import lgpl3.o.O;
import lgpl3.o.ary.Aryva;

/**
 * To distinct.<br/>
 * To distinct.
 *
 * @version 2022/10/11_09:50:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Ex018_DistinctValInAry" >src</a>
 *
 */
public class Ex018_DistinctValInAry {

	public static void main(String[] sAry) throws Throwable {

		long[] ary = { 10, 80, 20, 49, 40, 40, 40, 50, 50 };
		long[] clonedAry = ary.clone();

		Arrays.sort(ary);

		O.l("easyDistinct=");
		O.l(ary = Aryva.easyDistinct(ary));

		Arrays.sort(clonedAry);

		if (!Arrays.equals(ary, Aryva.distinct(clonedAry)))

			O.x();

	}
}