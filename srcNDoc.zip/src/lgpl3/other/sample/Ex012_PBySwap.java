package lgpl3.other.sample;

import lgpl3.comb.Pnk;
import lgpl3.comb.b64WVCell.B64W6;
import lgpl3.o.B;
import lgpl3.o.O;
import lgpl3.o.ary.Ary32va;
import lgpl3.o.keyNV.KAryV32;
import lgpl3.o.time.T64;

/**
 * Permutation.<br/>
 * Permutation.
 *
 * @version 2022/06/05_11:40:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Ex012_PBySwap" >src</a>
 *
 */
public class Ex012_PBySwap {

	/**
	 * To string by B64W6.<br/>
	 * To string by B64W6.
	 */
	public static StringBuilder toStrNotRev(long b64W6) {

		StringBuilder ret = new StringBuilder(O.defLenForStr);

		do {
			ret.append(O.S_ARY_A_Z[(((int) b64W6) & B64W6.MASK32) - 1]);

			if (((int) (b64W6 >>>= B64W6.$6)) == 0b0)

				return ret;

			ret.append(O.C44);

		} while (B.I);

	}

	/**
	 * To string by B64W6.<br/>
	 * To string by B64W6.
	 */
	public static StringBuilder toStr(long[] ary) {

		StringBuilder ret = new StringBuilder(O.defLenForStr);

		for (int idx = 0; idx != ary.length;) {

			ret.append(toStrNotRev(ary[idx]));

			if (++idx != ary.length)

				ret.append(O.C_A_L);

		}

		return ret;

	}

	/**
	 * 從 1 全相異數列中取出 k 個數做排列.<br/>
	 * To pick several numbers from a list of distinct numbers then to permutate.
	 */
	public static void pBySwap(long prefix, int len, int from, KAryV32 kV) {

		++B.n32;

		int fromPlus1 = from + 1;
		if (fromPlus1 == len) {

			kV.k[kV.v++] = prefix;

			return;

		}

		pBySwap(prefix, len, fromPlus1, kV); // i==from 跳過不用 swap 故不用每次都 swap

		for (int i = fromPlus1; i != len; i++)

			pBySwap(B64W6.swapVCell(prefix, from, i), len, fromPlus1, kV); // i==from 跳過不用 swap 故不用每次都 swap

	}

	public static void main(String[] args) throws Throwable {

		int n = 11;

		long prefix = B64W6.genB64W6ByAry32(Ary32va.genAscAry32From1(n));

		KAryV32 kV = new KAryV32(Pnk.int64(n));

		long t0 = O.t();

		pBySwap(prefix, n, 0, kV); // todo: call Cva first

		float tF = T64.difInF32Sec(t0);

		if (n <= 8)

			O.l(toStr(kV.k));

		O.l("len=" + O.f(O.eq(kV.v, Pnk.int64(n))));
		O.l("costT=" + tF);
		O.l("nOfCall=" + O.f(B.n32));

		B.n32 = 0;

		O.l("===================================");

		kV.v = 0;

		t0 = O.t();

		Pnk.colRecurWNGteK(~(-0b1 << n), 0b0L, 0, n, kV);

		tF = T64.difInF32Sec(t0);

		if (n <= 8)

			O.l(Pnk.strByAryOfRevB64W6BySAry(kV.k, O.S_ARY_A_Z));

		O.l("len=" + O.f(O.eq(kV.v, Pnk.int64(n))));
		O.l("costT=" + tF);
		O.l("nOfCall=" + O.f(B.n32));

		B.n32 = 0;

	}
}