package lgpl3.other.sample;

import lgpl3.comb.selfCallva.ForwardSelfCallva;
import lgpl3.o.O;

/**
 * To print vertically.<br/>
 * To print.
 *
 * @version 2023/04/25_14:00:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Ex006_PrintByCallSelf" >src</a>
 *
 */
public class Ex006_PrintByCallSelf {

	public static void main(String[] sAry) throws Throwable {

		ForwardSelfCallva.printByCallSelf(3, 20, 2); // from 3 to 10 with step is 2

		O.l("=======");

		int[] ary = { 200, 210, 220, 230 };

		ForwardSelfCallva.print(ary, 1);

	}
}
