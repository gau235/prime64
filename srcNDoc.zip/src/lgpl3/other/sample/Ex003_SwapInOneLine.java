package lgpl3.other.sample;

import lgpl3.o.O;

/**
 * To swap.<br/>
 * To swap.
 *
 * @version 2023/06/15_18:40:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Ex003_SwapInOneLine" >src</a>
 *
 */
public class Ex003_SwapInOneLine {

	public static void swap(int a, int b) {

		final int oldA = a;
		final int oldB = b;

		int tmp = a;
		a = b;
		b = tmp;

		O.l("swap a=" + O.eq(a, oldB) + " b=" + O.eq(b, oldA));

	}

	public static void swapByXor(int a, int b) {

		final int oldA = a;
		final int oldB = b;

		// a = a ^ b;
		// b = a ^ b;
		// a = a ^ b;

		a = a ^ b ^ (b = a);

		O.l("swapByXor a=" + O.eq(a, oldB) + " b=" + O.eq(b, oldA));

	}

	public static void swapByAdd(int a, int b) {

		final int oldA = a;
		final int oldB = b;

		// a += b;
		// b = a - b;
		// a -= b;

		a = a + b - (b = a);

		O.l("swapByAdd a=" + O.eq(a, oldB) + " b=" + O.eq(b, oldA));

	}

	public static void swapByAdd2(int a, int b) {

		final int oldA = a;
		final int oldB = b;

		a = (a & b) + (a | b); // same as a = a + b
		b = a + (~b) + 0b1; // same as b = a - b
		a = a + (~b) + 0b1;

		O.l("swapByAdd2 a=" + O.eq(a, oldB) + " b=" + O.eq(b, oldA));

	}

	public static void swapByMul(int a, int b) {

		final int oldA = a;
		final int oldB = b;

		// a = a * b;
		// b = a / b;
		// a = a / b;

		a = (a * b) / (b = a);

		O.l("swapByMul a=" + O.eq(a, oldB) + " b=" + O.eq(b, oldA));

	}

	public static void main(String[] sAry) {

		int a = 11;
		int b = 22;

		O.l("bef a=" + a + " b=" + b);
		swap(a, b);

		swapByXor(a, b);

		swapByAdd(a, b);
		swapByAdd2(a, b);

		swapByMul(a, b);

	}
}
