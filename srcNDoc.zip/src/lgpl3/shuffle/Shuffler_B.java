package lgpl3.shuffle;

import lgpl3.comb.Pnk;
import lgpl3.comb.b64WVCell.B64W6;
import lgpl3.o.B;
import lgpl3.o.O;
import lgpl3.o.ary.Aryva;

/**
 * @version 2022/09/25_10:10:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Shuffler_B" >src</a>
 *
 * @see Shuffler
 */
public abstract class Shuffler_B extends Shuffler_A {

	private static final Class<?> THIS = Shuffler.class;

	/**
	 * To sum.
	 */
	public static float sumOfInv(int nAftFac) {

		// int nTestOfEveryRow = const* (nPowN / facOfN );

		// 有想過 (n!power(n!)) / (n!)!

		float ans = 0F;

		for (int from = 1; from != nAftFac; from++)

			ans += 1 / ((float) from);

		O.l("nAftFac=" + nAftFac + " sumOfInv=" + ans, THIS);

		return ans;

	}

	/**
	 * To shuffle.
	 */
	public static long[] shuffleForPnk(long[] aryOfB64W6) {

		int totalVCell = B64W6.totalVCell(aryOfB64W6[0]), iBase = 0, baseLen = aryOfB64W6.length, iAry, nTestOfEveryRow;

		O.l("totalVCell=" + totalVCell, THIS);

		if (totalVCell == 1)

			return aryOfB64W6;

		nTestOfEveryRow = (int) Pnk.int64(totalVCell);

		nTestOfEveryRow = (int) (nTestOfEveryRow * sumOfInv(nTestOfEveryRow));

		O.l("nTestOfEveryRow=" + O.f(nTestOfEveryRow), THIS);

		nTestOfEveryRow = ((int) ((nTestOfEveryRow / 2.7F + 2) * totalVCell)) + 1;

		O.l("nTestOfEveryRow2=" + O.f(nTestOfEveryRow), THIS);

		long retAry[] = new long[nTestOfEveryRow], tmp;

		for (tmp = aryOfB64W6[iBase], iAry = 0; iAry != nTestOfEveryRow;)

			retAry[iAry++] = shuffle(tmp, totalVCell);

		retAry = Aryva.distinct(O.delTailAll0(retAry)); // first one

		if (++iBase == baseLen)

			return retAry;

		long[] tmpAry = new long[nTestOfEveryRow];

		do {
			if (totalVCell >= 7)

				O.l("iBase=" + iBase, THIS);

			for (tmp = aryOfB64W6[iBase], iAry = 0; iAry != nTestOfEveryRow;)

				tmpAry[iAry++] = shuffle(tmp, totalVCell);

			retAry = Aryva.mergeNDistinct(retAry, O.delTailAll0(tmpAry));

			if (++iBase == baseLen)

				return retAry;

			tmpAry = new long[nTestOfEveryRow];

		} while (B.I);
	}
}
