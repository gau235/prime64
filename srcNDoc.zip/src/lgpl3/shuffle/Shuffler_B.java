package lgpl3.shuffle;

import java.util.Arrays;

import lgpl3.comb.Pnk;
import lgpl3.comb.b64WVCell.B64W6;
import lgpl3.o.B;
import lgpl3.o.O;
import lgpl3.o.ary.Aryva;

/**
 * @version 2022/09/25_10:10:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Shuffler_B" >src</a>
 *
 * @see Shuffler
 */
public abstract class Shuffler_B extends Shuffler_A {

	private static final Class<?> THIS = Shuffler.class;

	/**
	 * To sum.
	 */
	public static int sumOfInv(int totalVCell) {

		int nAftFac = (int) Pnk.int64(totalVCell), sumOfInv = 0;

		for (int unselectedQty = nAftFac; unselectedQty != 0; unselectedQty--) {

			sumOfInv += (nAftFac / unselectedQty);

			if (nAftFac % unselectedQty != 0)

				sumOfInv++;

		}

		O.l("sumOfInv=" + O.f(sumOfInv), THIS);

		return sumOfInv;

	}

	/**
	 * The number of tests.
	 */
	public static int sumOfFac(int totalVCell) { // (n!)*(n!) 想 (n!)*(n!-1)

		// 有想過 [(n!)!] / [(n!)^(n!)]

		int sumOfFac = (int) Pnk.int64(totalVCell);

		sumOfFac *= sumOfFac - 1;

		O.l("sumOfFac=" + O.f(sumOfFac), THIS);

		return sumOfFac;

	}

	/**
	 * To shuffle.
	 */
	public static long[] shuffleForPnk(long[] aryOfB64W6, float rate) {

		int totalVCell = B64W6.totalVCell(aryOfB64W6[0]), iBase = 0, baseLen = aryOfB64W6.length, iAry, nTestOfPerRow;

		if (totalVCell == 1)

			return aryOfB64W6;

		nTestOfPerRow = (O.rnd100() < 99) ? ((int) (sumOfInv(totalVCell) * rate)) : sumOfFac(totalVCell);

		O.l("totalVCell=" + totalVCell + " nTestOfPerRow=" + O.f(nTestOfPerRow), THIS);
		O.l("rate=" + rate);

		long ret[] = new long[nTestOfPerRow], tmp, tmpAry[];

		for (tmp = aryOfB64W6[iBase], iAry = 0; iAry != nTestOfPerRow;)

			ret[iAry++] = shuffle(tmp, totalVCell);

		Arrays.sort(ret); // 破壞性寫入

		ret = Aryva.distinct(ret); // first one

		if (++iBase == baseLen)

			return ret;

		// O.l("baseLen=" + baseLen, THIS);

		tmpAry = new long[nTestOfPerRow];

		do {
			if (totalVCell >= 8)

				O.l("iBase=" + iBase, THIS);

			for (tmp = aryOfB64W6[iBase], iAry = 0; iAry != nTestOfPerRow;)

				tmpAry[iAry++] = shuffle(tmp, totalVCell);

			Arrays.sort(tmpAry); // 破壞性寫入

			ret = Aryva.merge(ret, Aryva.distinct(tmpAry));

			if (++iBase == baseLen) {

				O.l("iBase=" + iBase, THIS);

				return ret;

			}

			tmpAry = new long[nTestOfPerRow];

		} while (B.T);
	}
}
