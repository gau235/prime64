package lgpl3.shuffle.sample;

import lgpl3.b32.B32va;
import lgpl3.comb.Cnk;
import lgpl3.comb.b64WVCell.B64W6;
import lgpl3.o.B;
import lgpl3.o.O;
import lgpl3.o.ary.Ary32va;
import lgpl3.shuffle.Shuffler;

/**
 * 排列的實驗法及逼近法<br/>
 * <br/>
 *
 * 排列 [A,B,C]<br/>
 * <br/>
 * 1. 取數列的子集合 <br/>
 * 2. 放入容器以過濾重複<br/>
 * <br/>
 *
 * 部份相同物排列 [A,A,B]<br/>
 * <br/>
 * 1. 取數列的子集合<br/>
 * 2. 放入容器以過濾重複<br/>
 * <br/>
 *
 * 組合 (取物) [A,B,C]<br/>
 * <br/>
 * 1. 取數列的子集合<br/>
 * 2. 排序<br/>
 * 3. 放入容器以過濾重複<br/>
 * <br/>
 *
 * 部份相同物組合 (取物) [A,A,B]<br/>
 * <br/>
 * 1. 取數列的子集合<br/>
 * 2. 排序<br/>
 * 3. 放入容器以過濾重複<br/>
 *
 * @version 2023/04/27_00:00:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Ex92_RndPickKNRetB32As2Pow" >src</a>
 *
 */
public class Ex92_RndPickKNRetB32As2Pow { // Cnk

	public static void main1(String[] sAry) throws Throwable {

		int n = 8;
		int k = 4;

		int ret = Shuffler.pickKNRetB32As2Pow(n, k);

		O.l("ret=" + B32va.str(ret));

	}

	public static void main(String[] sAry) throws Throwable {

		int n = 15;
		int k = 3;

		float rate = 1F;

		int[] ret = Ary32va.sortNCheckDup(Shuffler.shuffleForCnk(n, k, rate));

		for (int i = 0; i != ret.length; i++)

			O.l(B64W6.strByVCellMinus1AftRevBySAry(B64W6.toDescB64W6ByLog2NPlus1(ret[i]), O.S_ARY_A_Z));

		O.l("total=" + ret.length + " ansC=" + Cnk.int64(n, k) + " B.cnt=" + B.cnt);

	}
}