package lgpl3.shuffle.sample;

import lgpl3.comb.b64WVCell.B64W6;
import lgpl3.o.O;
import lgpl3.shuffle.Shuffler;

/**
 * To shuffle the array.<br/>
 *
 * @version 2022/09/16_21:50:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Ex88_ShuffleB64W6" >src</a>
 *
 */
public class Ex88_ShuffleB64W6 {

	public static void main(String[] sAry) throws Throwable {

		long b64W6 = B64W6.genB64W6ByAry32(1, 2, 3, 4);
		O.l("bef=" + O.L + B64W6.str24(b64W6));

		b64W6 = Shuffler.shuffle(b64W6, B64W6.totalVCell(b64W6));

		O.l("aft=" + O.L + B64W6.str24(b64W6));

	}
}