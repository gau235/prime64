package lgpl3.shuffle.sample;

import java.util.Arrays;

import lgpl3.comb.Cnk;
import lgpl3.comb.b64WVCell.B64W6;
import lgpl3.comb.filter.IdxSet32;
import lgpl3.o.O;
import lgpl3.o.keyNV.KAryV32;
import lgpl3.shuffle.Shuffler;

/**
 * 排列的實驗法及逼近法<br/>
 * <br/>
 *
 * 排列 [A,B,C]<br/>
 * <br/>
 * 1. 取數列的子集合 <br/>
 * 2. 放入容器以過濾重複<br/>
 * <br/>
 *
 * 部份相同物排列 [A,A,B]<br/>
 * <br/>
 * 1. 取數列的子集合<br/>
 * 2. 放入容器以過濾重複<br/>
 * <br/>
 *
 * 組合 (取物) [A,B,C]<br/>
 * <br/>
 * 1. 取數列的子集合<br/>
 * 2. 排序<br/>
 * 3. 放入容器以過濾重複<br/>
 * <br/>
 *
 * 部份相同物組合 (取物) [A,A,B]<br/>
 * <br/>
 * 1. 取數列的子集合<br/>
 * 2. 排序<br/>
 * 3. 放入容器以過濾重複<br/>
 *
 * @version 2022/05/17_10:50:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Ex92_NaturallyPickKNRetB64W6" >src</a>
 *
 */
public class Ex92_NaturallyPickKNRetB64W6 { // Cnk

	public static void main(String[] sAry) throws Throwable {

		int nTest = 150;

		int ary32[] = { 1, 2, 3, 4, 5, 6, 7, 8 }, k = 3;

		O.l("ary32=");
		O.l(ary32);

		long b64, tmpAry[];

		IdxSet32 idxSet32 = new IdxSet32(B64W6.$MAX_INT32_IN_CELL);
		KAryV32 kV = new KAryV32(Cnk.int64(ary32.length, k));

		do
			if (idxSet32.addIfNotFound(b64 = B64W6.easySortDesc(Shuffler.pickKNRetB64W6(ary32, k), k)))

				kV.k[kV.v++] = b64;

		while (--nTest != 0);

		Arrays.sort(tmpAry = Arrays.copyOf(kV.k, kV.v));

		StringBuilder str = new StringBuilder(O.defLenForStr);

		O.l("tmpAry=");
		for (; kV.v-- != 0;)

			str.append(B64W6.strByVCellAftRev(tmpAry[kV.v])).append(O.C_A_L).append(O.C_A_L);

		O.l(str.append("total=" + tmpAry.length));

	}
}