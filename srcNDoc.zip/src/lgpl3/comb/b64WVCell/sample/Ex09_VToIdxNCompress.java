package lgpl3.comb.b64WVCell.sample;

import lgpl3.b32.B32va;
import lgpl3.comb.b64WVCell.B64W6;
import lgpl3.comb.filter.BitRow;
import lgpl3.o.O;

/**
 * To cmpress.<br/>
 * To cmpress.
 *
 * @version 2023/05/21_22:00:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Ex09_VToIdxNCompress" >src</a>
 *
 */
public class Ex09_VToIdxNCompress {

	public static void main(String[] sAry) throws Throwable {

		long b64W6 = B64W6.genB64W6ByAry32(1, 2, 14);

		int b32 = B64W6.toB32As2PowByB6Cell(b64W6);

		B64W6.toB64W6ByLog2NPlus1(b32);

		O.l("b32=" + B32va.str(b32));

		b64W6 = B64W6.genB64W6ByAry32(11);

		b64W6 = BitRow.vToIdxNCompress(B64W6.easySortAftTotalVCell(b64W6));

		O.l("vToIdxNCompress=" + O.L + B64W6.str(b64W6));

	}
}
