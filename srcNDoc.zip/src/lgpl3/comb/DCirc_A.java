package lgpl3.comb;

import java.math.BigInteger;

import lgpl3.o.O;

/**
 * 環狀排列且全錯排.<br/>
 * Derangement and circular permutation.
 *
 * @version 2022/09/30_07:40:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=DCirc_A" >DCirc_A.java</a>
 *
 * @see DCirc
 */
public abstract class DCirc_A {

	// private static final Class<?> THIS = DCirc_A.class;

	/**
	 * 回傳 Dnk as circ.<br/>
	 * Dnk as circ.
	 */
	public static long int64(int n) {

		// if (n < 0) O.x("n=" + n);

		if (n == 1)

			return 0L;

		if (n == 2)

			return 1L;

		if (n == 3)

			return 1L;

		if (n == 4)

			return 6L;

		if (n == 5)

			return 21L;

		if (n == 6)

			return 120L;

		if (n == 7)

			return 701L;

		if (n == 8)

			return 5_040L;

		if (n == 9)

			return 40_095L;

		if (n == 10)

			return 362_880L;

		if (n == 11)

			return 3_625_359L;

		if (n == 12)

			return 39_916_800L;

		if (n == 13)

			return 478_922_341L;

		if (n == 14)

			return 6_227_020_800L;

		if (n == 15)

			return 87_175_867_005L; // costT=6300 sec

		if (n == 16)

			return 1_307_674_368_000L;

		if (n == 17)

			return 20_922_695_416_911L;

		if (n == 18)

			return 355_687_428_096_000L;

		if (n == 19)

			return 6_402_369_092_207_111L;

		if (n == 20)

			return 121_645_100_408_832_000L;

		if (n == 21)

			return 2_432_901_733_027_986_885L;

		// https://oeis.org/A003111/b003111.txt
		// # A003111 (b-file synthesized from sequence entry)
		// 0: 1 Dc1=Pc1-1=0
		// 1: 1 Dc3=Pc3-1=1
		// 2: 3 Dc5=Pc5-3=21
		// 3: 19 Dc7=Pc7-19=701
		// 4: 225 Dc9=40_320-225=40_095
		// 5: 3441 Dc11=3_628_800-3_441=3_625_359
		// 6: 79259 Dc13
		// 7: 2424195 Dc15
		// 8: 94471089 Dc17
		// 9: 4613520889 Dc19
		// 10: 275148653115 Dc21
		// 11: 19686730313955 Dc23
		// 12: 1664382756757625 Dc25

		throw new IllegalArgumentException("n=" + n);

	}

	/**
	 * 回傳亂序數.<br/>
	 * 即 n 個人排成一列後解散再排成一列, 沒有人排在自己原先的位置的方法數.<br/>
	 * D(n,k)=C(n,k)*D(k)<br/>
	 * To return the number of ways that n people line up then dismiss, and<br/>
	 * line up again but nobody is at the previous position.
	 */
	public static long int64(int n, int k) {

		return Cnk.int64(n, k) * int64(k);
	}

	/**
	 * 回傳亂序數.<br/>
	 * 即 n 個人排成一列後解散再排成一列, 沒有人排在自己原先的位置的方法數.<br/>
	 * D(n,k)=C(n,k)*D(k)<br/>
	 * To return the number of ways that n people line up then dismiss, and<br/>
	 * line up again but nobody is at the previous position.
	 */
	public static BigInteger bigInt(int n) {

		if (n <= 21)

			return BigInteger.valueOf(int64(n));

		if ((n & 0b1) != 0b0)

			O.x("n=" + n);

		return PCirc.bigInt(n);

	}

	/**
	 * 回傳亂序數.<br/>
	 * 即 n 個人排成一列後解散再排成一列, 沒有人排在自己原先的位置的方法數.<br/>
	 * D(n,k)=C(n,k)*D(k)<br/>
	 * To return the number of ways that n people line up then dismiss, and<br/>
	 * line up again but nobody is at the previous position.
	 */
	public static BigInteger bigInt(int n, int k) {

		return Cnk.bigInt(n, k).multiply(bigInt(k));
	}
}
