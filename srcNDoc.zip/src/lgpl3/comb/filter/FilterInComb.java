package lgpl3.comb.filter;

import lgpl3.comb.Cnk;

/**
 * To filter.<br/>
 * To filter.
 *
 * @version 2022/01/29_11:50:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=FilterInComb" >FilterInComb.java</a>
 *
 * @see Cnk
 */
public abstract class FilterInComb extends FilterInComb_A {

	// private static final Class<?> THIS = FilterInComb.class;
}