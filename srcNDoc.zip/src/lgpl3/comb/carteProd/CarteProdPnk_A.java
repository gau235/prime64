package lgpl3.comb.carteProd;

import lgpl3.comb.Pnk;
import lgpl3.comb.b64WVCell.B64W6;

/**
 * To product.<br/>
 * To product.
 *
 * @version 2020/09/23_20:10:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=CarteProdPnk_A" >CarteProdPnk_A.java</a>
 *
 * @see CarteProdPnk_L
 */
public abstract class CarteProdPnk_A extends CarteProd {

	// private static final Class<?> THIS = CarteProdPnk_A.class;

	/**
	 * To product.<br/>
	 * To product.
	 *
	 * @see CarteProdCnk#mulAmongBoxWTag(int, long)
	 */
	public static long mulAmongBoxWTag(int n, long b64W6) {

		long ans = 1L;

		int vCell = ((int) b64W6) & B64W6.MASK32;
		do {
			ans *= Pnk.int64(n, vCell);
			n -= vCell;

		} while ((vCell = ((int) (b64W6 >>>= B64W6.$6)) & B64W6.MASK32) != 0b0);

		return ans;

	}

	/**
	 * To product.<br/>
	 * To product.
	 *
	 * @see CarteProdCnk#mulAmongHeap(int, long)
	 */
	public static long mulAmongHeap(int n, long sortedB64W6) { // must be sorted for countDu

		long oldB64W6 = sortedB64W6, ret = 1L; // must keep sortedB64W6

		int vCell = (((int) sortedB64W6) & B64W6.MASK32), b32W6;
		do {
			ret *= Pnk.int64(n, vCell);
			n -= vCell;

		} while ((vCell = ((int) (sortedB64W6 >>>= B64W6.$6)) & B64W6.MASK32) != 0b0);

		if ((b32W6 = B64W6.countDupNRev(oldB64W6)) == 0b0)

			return ret;

		do
			ret /= Pnk.int64(b32W6 & B64W6.MASK32);

		while ((b32W6 >>>= B64W6.$6) != 0b0);

		return ret; // O.l("ret=" + ret, THIS);

	}
}
