package lgpl3.comb;

import lgpl3.comb.b64WVCell.B64W6;
import lgpl3.o.B;
import lgpl3.o.keyNV.KArV32;

/**
 * @version 2022/06/24_10:10:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Pnk_W" >src</a>
 *
 * @see Pnk_Z
 */
public abstract class Pnk_W extends Pnk_J {

	private static final Class<?> THIS = Pnk_W.class;

	/**
	 * 從 1 全相異數列中取出 k 個數做排列.<br/>
	 * To pick several numbers from a list of distinct numbers then to permutate.
	 */
	public static void colBySwap(int n, long prefix, int from, KArV32 ar) {

		B.cnt++;

		int fromPlus1 = from + 1;

		if (fromPlus1 == n - 1) { // 剩下 2 個

			ar.k[ar.v++] = prefix;

			do
				ar.k[ar.v++] = B64W6.swapVCell(prefix, from, fromPlus1);

			while (++fromPlus1 != n);

			return;

		}

		// 不交換 一次跑到底
		colBySwap(n, prefix, fromPlus1, ar); // 當 nxt==from 跳過 不用每次都 swap

		for (int nxt = fromPlus1; nxt != n; nxt++)

			colBySwap(n, B64W6.swapVCell(prefix, from, nxt), fromPlus1, ar);

	}

	/**
	 * 從 1 列全相異數列中取出 k 個數.<br/>
	 * To pick several numbers from a list of distinct numbers.
	 */
	public static void cBefColBySwap(final int boundBit, int rmdK, int prefix, int curBit, KArV32 kV) {

		if (--rmdK == 0) {

			final int n = Integer.bitCount(prefix) + 1; // O.l("n=" + n, THIS);

			do
				colBySwap(n, B64W6.toB64W6ByLog2NPlus1(curBit | prefix), 0, kV);

			while ((curBit <<= 1) != boundBit);

			return;

		}

		int newBoundBit = boundBit >>> rmdK;

		do
			cBefColBySwap(boundBit, rmdK, (curBit | prefix), (curBit <<= 1), kV);

		while (curBit != newBoundBit);

	}

	/**
	 * 從 1 全相異數列中取出 k 個數做排列.<br/>
	 * To pick several numbers from a list of distinct numbers then to permutate.
	 */
	public static long[] colBySwap(int n, int k) {

		KArV32 retKV = new KArV32(int64(n, k));

		cBefColBySwap((0b1 << n), k, 0b0, 0b1, retKV);

		return retKV.k;

	}

	/**
	 * 從 1 全相異數列中取出 k 個數做排列.<br/>
	 * To pick several numbers from a list of distinct numbers then to permutate.
	 */
	public static void colBySwapWNGteK(int n, int k, long prefix, int from, KArV32 kV) { // 改良 PBySwap

		B.cnt++;

		int fromPlus1 = from + 1;

		if (fromPlus1 == k) {

			// 交換後, 只取前幾個, 所以用 mask 遮蔽
			long mask = ~(B64W6.MASK0_1TO_6 << (B64W6.$6 * from)); // O.l("mask=" + B64W6.str(mask), THIS);

			kV.k[kV.v++] = prefix & mask;

			for (int v32; fromPlus1 != n; fromPlus1++) {

				v32 = ((int) (prefix >>> (B64W6.$6 * fromPlus1))) & B64W6.MASK32;

				kV.k[kV.v++] = B64W6.pasteAt(prefix, from, v32) & mask;

			}

			return;

		}

		// 不交換 一次跑到底
		colBySwapWNGteK(n, k, prefix, fromPlus1, kV); // 當 nxt==from 跳過 不用每次都 swap

		for (int nxt = fromPlus1; nxt != n; nxt++)

			colBySwapWNGteK(n, k, B64W6.swapVCell(prefix, from, nxt), fromPlus1, kV);

	}
}
