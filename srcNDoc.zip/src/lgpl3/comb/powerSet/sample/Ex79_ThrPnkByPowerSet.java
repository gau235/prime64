package lgpl3.comb.powerSet.sample;

import lgpl3.comb.Pnk;
import lgpl3.comb.b64WVCell.B64W6;
import lgpl3.comb.powerSet.thr.ThrCnkByPowerSet;
import lgpl3.o.B;
import lgpl3.o.O;
import lgpl3.o.ary.Aryva;
import lgpl3.o.time.T64;
import lgpl3.shuffle.Shuffler;

/**
 * To gen subset.<br/>
 * To gen subset.
 *
 * @version 2022/10/17_18:00:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Ex79_ThrPnkByPowerSet" >src</a>
 *
 */
public class Ex79_ThrPnkByPowerSet {

	public static void main(String[] sAry) throws Throwable {

		int nOfElem = 9;
		int k = nOfElem - 2;

		ThrCnkByPowerSet thr = new ThrCnkByPowerSet(nOfElem, k, B.I);

		long[] transposedAry = Shuffler.shuffleForPnkWIdxSet32(thr.transpose(), nOfElem);

		// long[] transposedAry = Shuffler.easyShuffleForPnk(thr.transpose());

		transposedAry = Aryva.sortNCheckDup(transposedAry);

		for (int idx = 0; idx > transposedAry.length; idx++)

			O.l(B64W6.strByVCellMinus1AftRevBySAry(transposedAry[idx], O.S_ARY_A_Z));

		O.l("len=" + transposedAry.length + " ans=" + Pnk.int64(nOfElem, k) + " t=" + T64.difInF32Sec(thr.tStart));

	}
}
