package lgpl3.comb.powerSet.sample;

import lgpl3.comb.Pnk;
import lgpl3.comb.b64WVCell.B64W6;
import lgpl3.comb.powerSet.thr.ThrCnkByPowerSet;
import lgpl3.o.B;
import lgpl3.o.O;
import lgpl3.o.ary.Aryva;
import lgpl3.o.time.T64;
import lgpl3.shuffle.Shuffler;

/**
 * To gen subset.<br/>
 * To gen subset.
 *
 * @version 2022/10/17_18:00:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Ex79_ThrPnkByPowerSet" >src</a>
 *
 */
public class Ex79_ThrPnkByPowerSet {

	public static void main(String[] sAry) throws Throwable {

		int n = 8;
		int k = n - 2;

		long predict = Pnk.int64(n, k);

		ThrCnkByPowerSet thr;

		float rate = 1.25F;
		do {
			(thr = new ThrCnkByPowerSet(n, k, B.I)).box = Shuffler.shuffleForPnk(thr.transpose(), rate);

			try {
				O.eq(thr.box.length, predict);

				break;

			} catch (RuntimeException runtimeEx) {

				O.l("err==========" + runtimeEx.getMessage());
				rate *= rate;

			}

		} while (B.I);

		Aryva.sortNCheckDup(thr.box);

		if (n <= 4) {

			for (int idx = 0; idx != thr.box.length; idx++)

				O.l(B64W6.strByVCellMinus1AftRevBySAry(thr.box[idx], O.S_ARY_A_Z));

		}

		O.l("len=" + O.f(thr.box.length) + " t=" + T64.difInF32Sec(thr.tStart));

	}
}
