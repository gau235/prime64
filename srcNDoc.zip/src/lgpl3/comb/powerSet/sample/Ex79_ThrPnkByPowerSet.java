package lgpl3.comb.powerSet.sample;

import lgpl3.comb.Pnk;
import lgpl3.comb.b64WVCell.B64W6;
import lgpl3.comb.powerSet.thr.ThrCnkByPowerSet;
import lgpl3.o.B;
import lgpl3.o.O;
import lgpl3.o.ary.Aryva;
import lgpl3.o.time.T64;
import lgpl3.shuffle.Shuffler;

/**
 * To gen subset.<br/>
 * To gen subset.
 *
 * @version 2022/10/17_18:00:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Ex79_ThrPnkByPowerSet" >src</a>
 *
 */
public class Ex79_ThrPnkByPowerSet {

	public static void main(String[] sAry) throws Throwable {

		int n = 11;
		int k = n - 2;

		long predict = Pnk.int64(n, k);

		ThrCnkByPowerSet thr = new ThrCnkByPowerSet(n, k, B.I);

		thr.transpose();

		long[] retAry;

		float rate = 2.34F;
		do {
			retAry = Shuffler.shuffleForPnk(thr.box.clone(), rate);

			try {
				O.eq(retAry.length, predict);

				break;

			} catch (RuntimeException runtimeEx) {

				O.l("err==========" + runtimeEx.getMessage());

				rate *= rate; // important

			}

		} while (B.I);

		Aryva.sortNCheckDup(retAry);

		if (n <= 4) {

			for (int idx = 0; idx != retAry.length; idx++)

				O.l(B64W6.strByVCellMinus1AftRevBySAry(retAry[idx], O.S_ARY_A_Z));

		}

		O.l("len=" + O.f(retAry.length) + " t=" + T64.difInF32Sec(thr.tStart));

	}
}
