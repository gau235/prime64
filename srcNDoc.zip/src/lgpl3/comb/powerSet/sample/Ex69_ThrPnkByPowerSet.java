package lgpl3.comb.powerSet.sample;

import lgpl3.comb.b64WVCell.B64W6;
import lgpl3.comb.powerSet.thr.ThrCnkByPowerSet;
import lgpl3.o.B;
import lgpl3.o.O;
import lgpl3.o.ary.Aryva;
import lgpl3.shuffle.Shuffler;

/**
 * To gen subset.<br/>
 * To gen subset.
 *
 * @version 2022/09/17_18:00:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Ex69_ThrPnkByPowerSet" >Ex69_ThrPnkByPowerSet.java</a>
 *
 */
public class Ex69_ThrPnkByPowerSet {

	public static void main(String[] sAry) throws Throwable {

		int nOfElem = 5;
		int k = 4;

		ThrCnkByPowerSet thr = new ThrCnkByPowerSet(nOfElem, k, B.I);

		long[] transposedAry = Shuffler.shuffleForPnk(thr.transpose(), nOfElem);

		transposedAry = Aryva.sortNCheckDup(transposedAry);

		for (int idx = 0; idx != transposedAry.length; idx++)

			O.l(B64W6.strByVCellMinus1AftRevBySAry(transposedAry[idx], O.S_ARY_A_Z));

		O.l("total=" + transposedAry.length);

	}
}
