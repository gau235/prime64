package lgpl3.comb.powerSet.sample;

import lgpl3.comb.Pnk;
import lgpl3.comb.powerSet.thr.ThrPowerSetForCnk;
import lgpl3.o.B;
import lgpl3.o.O;

/**
 * To gen subset.<br/>
 * To gen subset.
 *
 * @version 2022/09/17_18:00:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Ex68_ThrGenPowerSetForCnk" >
 *          Ex68_ThrGenPowerSetForCnk.java</a>
 *
 */
public class Ex68_ThrGenPowerSetForCnk {

	public static void main(String[] sAry) throws Throwable {

		final int nOfElem = 5;
		final int k = 4;

		ThrPowerSetForCnk thr = new ThrPowerSetForCnk(nOfElem, k, B.I);

		long[] transposedAry = thr.transpose();

		O.l(Pnk.strByAryOfRevB64W6BySAry(transposedAry, O.S_ARY_A_Z));

		O.l("ans=" + thr.iLen);

		O.l("B.n32=" + B.n32);

		B.n32 = 0;

	}
}
