package lgpl3.comb.powerSet.sample;

import lgpl3.comb.Cnk;
import lgpl3.comb.Pnk;
import lgpl3.comb.b64WVCell.B64W6;
import lgpl3.comb.powerSet.thr.ThrCnkByPowerSet;
import lgpl3.o.B;
import lgpl3.o.O;

/**
 * To gen subset.<br/>
 * To gen subset.
 *
 * @version 2023/07/28_00:00:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Ex78_ThrCnkByPowerSet" >src</a>
 *
 */
public class Ex78_ThrCnkByPowerSet {

	public static void main(String[] sAry) throws Throwable {

		final int nOfElem = 5;
		final int k = 4;

		ThrCnkByPowerSet thr = new ThrCnkByPowerSet(nOfElem, k, B.T);

		O.l("box[0]=" + O.L + B64W6.str(thr.box[0]));

		long[] transposedAry = thr.transpose();

		O.l(Pnk.strByAryOfRevB64W6BySAry(transposedAry, O.S_ARY_A_Z));

		O.l("ans=" + O.eq(thr.iLen, Cnk.int64(nOfElem, k)));

		O.l("B.cnt=" + B.cnt);

		B.cnt = 0;

	}
}
