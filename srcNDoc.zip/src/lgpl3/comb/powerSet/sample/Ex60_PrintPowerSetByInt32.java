package lgpl3.comb.powerSet.sample;

import lgpl3.comb.powerSet.PowerSet;
import lgpl3.o.O;

/**
 * printPowerSetByInt32.<br/>
 * printPowerSetByInt32.
 *
 * @version 2022/11/27_10:50:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Ex60_PrintPowerSetByInt32" >src</a>
 *
 */
public class Ex60_PrintPowerSetByInt32 {

	public static void main(String[] sAry) throws Throwable {

		int[] base = { 1000, 200, 30, 4 }; // 1234 = 1000+200+30+4

		O.l("base=");
		O.l(base);
		O.l("=======");

		PowerSet.printPowerSetByInt32(base, 0, 0);

	}
}
