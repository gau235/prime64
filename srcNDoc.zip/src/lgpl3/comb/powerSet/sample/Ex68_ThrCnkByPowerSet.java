package lgpl3.comb.powerSet.sample;

import lgpl3.comb.Pnk;
import lgpl3.comb.b64WVCell.B64W6;
import lgpl3.comb.powerSet.thr.ThrCnkByPowerSet;
import lgpl3.o.B;
import lgpl3.o.O;

/**
 * To gen subset.<br/>
 * To gen subset.
 *
 * @version 2022/09/17_18:00:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Ex68_ThrCnkByPowerSet" >
 *          Ex68_ThrCnkByPowerSet.java</a>
 *
 */
public class Ex68_ThrCnkByPowerSet {

	public static void main(String[] sAry) throws Throwable {

		final int nOfElem = 5;
		final int k = 4;

		ThrCnkByPowerSet thr = new ThrCnkByPowerSet(nOfElem, k, B.I);

		O.l("box[0]=" + O.L + B64W6.str(thr.box[0]));

		long[] transposedAry = thr.transpose();

		O.l(Pnk.strByAryOfRevB64W6BySAry(transposedAry, O.S_ARY_A_Z));

		O.l("ans=" + thr.iLen);

		O.l("B.n32=" + B.n32);

		B.n32 = 0;

	}
}
