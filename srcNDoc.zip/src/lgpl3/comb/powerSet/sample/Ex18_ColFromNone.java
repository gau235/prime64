package lgpl3.comb.powerSet.sample;

import lgpl3.comb.powerSet.PowerSet;
import lgpl3.o.B;
import lgpl3.o.O;
import lgpl3.o.ary.Ary32_2D;

/**
 * To gen subset.<br/>
 * To gen subset.
 *
 * @version 2022/11/24_23:00:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Ex18_ColFromNone" >src</a>
 *
 */
public class Ex18_ColFromNone {

	public static void main(String[] sAry) throws Throwable {

		int[] base = new int[] { 10, 20, 33 };

		Ary32_2D ret = PowerSet.colFromNone(base);

		O.l(ret.toStr());

		O.l("total=" + ret.i);

		O.l("B.cnt=" + B.cnt);
		B.cnt = 0;

	}
}
