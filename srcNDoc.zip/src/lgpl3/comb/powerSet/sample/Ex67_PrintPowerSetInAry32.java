package lgpl3.comb.powerSet.sample;

import lgpl3.comb.powerSet.PowerSet;
import lgpl3.o.B;
import lgpl3.o.O;

/**
 * printPowerSetInAry32.<br/>
 * printPowerSetInAry32.
 *
 * @version 2022/11/27_10:50:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Ex67_PrintPowerSetInAry32" >src</a>
 *
 */
public class Ex67_PrintPowerSetInAry32 {

	public static void main(String[] sAry) throws Throwable {

		int[] ary = { 10, 20, 30 };

		O.l("ary=");
		O.l(ary);
		O.l("=======");

		PowerSet.printInAry32(ary, new int[ary.length], 0, 0, 0);

		O.l("B.cnt=" + B.cnt);
		B.cnt = 0;

	}
}
