package lgpl3.comb.powerSet.sample;

import lgpl3.comb.powerSet.PowerSet;

/**
 * To gen PowerSet.<br/>
 * To gen PowerSet.
 *
 * @version 2023/07/28_00:00:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Ex13_PrintPowerSetEasy" >src</a>
 *
 */
public class Ex13_PrintPowerSetEasy {

	public static void main(String[] sAry) throws Throwable {

		PowerSet.easyByBit(0b0, 3);
	}
}
