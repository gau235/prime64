package lgpl3.comb.powerSet.sample;

import lgpl3.comb.powerSet.PowerSet;
import lgpl3.o.O;
import lgpl3.o.ary.Seq32;

/**
 * printPowerSetBySeq32.<br/>
 * printPowerSetBySeq32.
 *
 * @version 2022/11/27_10:50:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Ex62_PrintPowerSetBySeq32" >src</a>
 *
 */
public class Ex62_PrintPowerSetBySeq32 {

	public static void main(String[] sAry) throws Throwable {

		int[] ary = { 10, 20, 30 };

		O.l("ary=");
		O.l(ary);
		O.l("=======");

		PowerSet.printPowerSetBySeq32(ary, new Seq32(), 0, 0);

	}
}
