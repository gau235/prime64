package lgpl3.comb.powerSet.sample;

import lgpl3.comb.powerSet.PowerSet;
import lgpl3.o.B;
import lgpl3.o.O;
import lgpl3.o.ary.Ary32_2D;
import lgpl3.o.ary.Seq32;

/**
 * To gen subset.<br/>
 * To gen subset.
 *
 * @version 2022/09/04_23:00:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Ex15_AllSubSet" >src</a>
 *
 */
public class Ex15_AllSubSet {

	public static void main(String[] sAry) throws Throwable {

		int base[] = { 10, 20, 30 }, idx = 0;

		Seq32 prefix = new Seq32();
		Ary32_2D ret = new Ary32_2D();

		PowerSet.colRecur(base, idx, prefix, ret);

		O.l(ret.toStr());

		O.l("total=" + ret.i);

		O.l("B.n32=" + B.n32);
		B.n32 = 0;

	}
}
