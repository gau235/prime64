package lgpl3.comb.powerSet.thr;

import lgpl3.comb.Cnk;
import lgpl3.comb.b64WVCell.B64W6;
import lgpl3.o.B;
import lgpl3.o.O;
import lgpl3.o.thr.ThrWBox;

/**
 * To gen subset.<br/>
 * To gen subset.
 *
 * @version 2022/09/20_21:30:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=ThrPowerSetForC" >ThrPowerSetForC.java</a>
 *
 */
public class ThrPowerSetForC extends ThrWBox<long[]> {

	private static final Class<?> THIS = ThrPowerSetForC.class;

	public final int nOfElem;

	public final int k;

	public static final int $YES = 0b1;

	public static final int $NO = 0b0;

	public int iLen;

	/**
	 * 建構方法.<br/>
	 * Constructor.
	 */
	public ThrPowerSetForC(int nOfElem, int k, boolean isToRun) {

		this.nOfElem = nOfElem;

		this.k = k;

		box = new long[(int) Cnk.int64(nOfElem, k)];

		if (isToRun) // pickItOrNot(0b0L, nOfElem);

			run();

	}

	/**
	 * To pick it or not. <br/>
	 * 旗標跟人名互換:<br/>
	 *
	 * 甲 乙 丙 丁<br/>
	 * Y N N Y => 甲丁
	 *
	 * 甲 乙 丙 丁<br/>
	 * Y Y N N => 甲乙
	 */
	public void pickItOrNot(long prefix, int lv) {

		B.n32++;

		// O.lv(lv, "prefix=" + B64W6.str24(prefix));

		if (lv == 0) {

			if (Long.bitCount(prefix) == k) // O.l("add prefix=" + B64W6.str24(prefix));

				box[iLen++] = prefix;

			return;

		}

		if ((Long.bitCount(prefix) + (lv--)) < k)

			return;

		pickItOrNot(((prefix << B64W6.$6) | $YES), lv);
		pickItOrNot((prefix << B64W6.$6), lv); // pickItOrNot(((prefix << B64W6.$6) | $NO), lv);

	}

	@Override
	public void run() {

		pickItOrNot(0b0L, nOfElem);
	}

	/**
	 * To string by B64W6.<br/>
	 * To string by B64W6.
	 */
	public StringBuilder toStr() {

		StringBuilder ret = new StringBuilder(O.defLenForStr);

		long myB64;
		for (int iBig = 0, iLocal; iBig != iLen;) {

			myB64 = box[iBig]; // O.l("myB64=" + B64W6.str24(myB64), THIS);

			iLocal = 0;
			do {
				if (((int) (myB64 & B64W6.MASK32)) == $YES) // 原創

					ret.append(O.S_ARY_A_Z[iLocal]); // sss += O.S_ARY_A_Z[iLocal];

				if ((myB64 >>>= B64W6.$6) == 0b0L)

					break;

				iLocal++;

			} while (B.I);

			if (++iBig != iLen)

				ret.append(O.C_A_L);

			// O.l("sss=" + sss, THIS);

		}

		return ret;

	}
}
