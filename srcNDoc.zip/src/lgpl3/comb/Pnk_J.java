package lgpl3.comb;

import lgpl3.b32.B32va;
import lgpl3.b64.B64va;
import lgpl3.comb.b64WVCell.B64W6;
import lgpl3.o.O;
import lgpl3.o.ary.Arr;
import lgpl3.o.keyNV.K64V32V32;

/**
 * @version 2022/10/13_21:50:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Pnk_J" >src</a>
 *
 * @see Pnk_W
 */
public abstract class Pnk_J extends Pnk_H {

	private static final Class<?> THIS = Pnk_J.class;

	/**
	 * 從 1 全相異數列中取出 k 個數做排列.<br/>
	 * 剪尾巴後再延伸法.
	 */
	public static long[] colByLoopBreadthNDepthFirst(int n, int k) { // 原創

		// rule: [1,2,3] => 1,2,31,32=>1,2,31,(321)=>1,2,(312),(321)=>1,23,21,(312),(321)=>...

		int rmdB32 = ~(-0b1 << n), allBullet, bullet, iStack = 0, iRet = 0;

		K64V32V32 stack[] = new K64V32V32[(n - 1) * k + 1], topKV; // todo: K64V32V32 改 K64V64V64

		O.l("stackLen=" + stack.length, THIS);

		long ret[] = new long[(int) int64(n, k)], prefix;

		if (--k == 0) {

			do
				ret[iRet++] = n;

			while (--n != 0);

			return ret;

		}

		// init
		allBullet = rmdB32;
		do
			stack[iStack++] = new K64V32V32(B32va.log2NPlus1(bullet = (-allBullet & allBullet)), (~bullet & rmdB32), k);

		while ((allBullet = (~bullet & allBullet)) != 0b0);
		// init ends

		O.l("k=" + k, THIS);

		O.l("stack=" + O.L + new Arr<K64V32V32>(stack).toStr(), THIS);
		O.l("iStack=" + iStack, THIS);

		do {
			topKV = stack[--iStack];

			prefix = topKV.k;
			rmdB32 = topKV.v1; // O.l("rmdB32=" + B32va.str16(rmdB32), THIS);
			k = topKV.v2;

			prefix <<= B64W6.$6;

			if (--k == 0) // 檢查是否剩下最後一個位元

				do
					ret[iRet++] = (prefix | B64va.log2NPlus1(bullet = (-rmdB32 & rmdB32)));

				while ((rmdB32 = (~bullet & rmdB32)) != 0b0L);

			else {

				allBullet = rmdB32;
				do
					stack[iStack++] = new K64V32V32((prefix | B32va.log2NPlus1(bullet = (-allBullet & allBullet))),

							(~bullet & rmdB32), k); // stack 增長 長尾巴

				while ((allBullet = (~bullet & allBullet)) != 0b0);

			}

		} while (iStack != 0);

		return ret;

	}
}
