package lgpl3.comb.selfCallva;

import java.util.Arrays;

import lgpl3.o.B;
import lgpl3.o.O;
import lgpl3.o.ary.Seq32;

/**
 * 本類別前進式自己呼叫自己的人.<br/>
 * To call self forward.
 *
 * @version 2022/04/04_10:00:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=ForwardSelfCallva" >src</a>
 *
 * @see Recur
 */
public abstract class ForwardSelfCallva extends ForwardSelfCallva_A {

	/**
	 * To gen all subset.
	 */
	public static void powerSet(int[] base, Seq32 prefix, int idx, int lv) { // 原創

		lv++;

		for (; idx < base.length;) {

			O.lv(lv, "prefix=" + prefix.toStr() + " ad " + base[idx]);

			powerSet(base, prefix.cNA(base[idx]), ++idx, lv); // 注意 有 ++idx

		}

		if (idx == base.length) { // 特殊寫法 終止條件在內部

			O.lv(lv, "fin " + prefix.toStr());

			return;

		}
	}

	/**
	 * To gen all subset.
	 */
	public static void powerSetOld(int[] base, Seq32 prefix, int idx, int lv) { // 原創

		for (; B.I;) {

			if (idx == base.length) { // 特殊寫法 終止條件在內部

				O.lv(lv, prefix.toStr() + " fin");

				return;

			}

			O.lv(lv, "prefix=" + prefix.toStr() + " ad " + base[idx]);

			powerSetOld(base, prefix.cNA(base[idx]), ++idx, lv + 1); // 注意 有 ++idx

		}
	}

	/**
	 * To gen all subset.
	 */
	public static void powerSet(int[] base, int[] prefix, int iPrefix, int iBase, int lv) {

		for (; B.I;) {

			if (iBase == base.length) { // 特殊寫法 終止條件在內部

				O.lv(lv, "iPrefix=" + iPrefix + " fin " + Arrays.toString(Arrays.copyOfRange(prefix, 0, iPrefix)));

				return;

			}

			O.lv(lv, "prefix=" + Arrays.toString(prefix) + " ad " + base[iBase]);

			prefix[iPrefix] = base[iBase];

			powerSet(base, prefix, iPrefix + 1, ++iBase, lv + 1);

		}
	}

	// public static void main1(String[] sAry) throws Throwable {
	public static void main(String[] sAry) throws Throwable {

		int[] ary = { 10, 20, 30 };

		O.l("ary=");
		O.l(ary);
		O.l("=======");

		powerSet(ary, new Seq32(), 0, 0);

	}

	public static void main2(String[] sAry) throws Throwable {
		// public static void main(String[] sAry) throws Throwable {

		int[] ary = { 10, 20, 30 };

		O.l("ary=");
		O.l(ary);
		O.l("=======");

		powerSet(ary, new int[ary.length], 0, 0, 1);

	}
}
