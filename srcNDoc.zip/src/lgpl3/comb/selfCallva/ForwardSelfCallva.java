package lgpl3.comb.selfCallva;

import lgpl3.comb.powerSet.PowerSet;
import lgpl3.o.B;
import lgpl3.o.O;
import lgpl3.o.ary.Ary32_2D;
import lgpl3.o.ary.Seq32;

/**
 * 本類別前進式自己呼叫自己的人.<br/>
 * To call self forward.
 *
 * @version 2022/04/04_10:00:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=ForwardSelfCallva" >src</a>
 *
 * @see Recur
 */
public abstract class ForwardSelfCallva extends ForwardSelfCallva_A {

	/**
	 * To StringBuilder.
	 */
	public static StringBuilder toStrByAry32(int[] ary32, int endIdx) {

		StringBuilder str = new StringBuilder(O.defLenForStr);

		str.append(O.C91);

		for (int idx = 0; idx != endIdx;) {

			str.append(ary32[idx]);

			if (++idx != endIdx)

				str.append(O.C44);

		}

		return str.append(O.C93);

	}

	/**
	 * To gen all subset.
	 *
	 * @see PowerSet #colFromNone(int[], int, Seq32, Ary32_2D, int)
	 */
	public static void printPowerSet(int[] baseAry32, Seq32 prefix, int idx, int lv) { // 原創

		B.n32++;

		lv++;

		// 特殊寫法 終止條件
		O.lv(lv, "idx=" + idx + " fin " + prefix.toStr());

		for (; idx != baseAry32.length; idx++) {

			// O.lv(lv, "prefix=" + prefix.toStr() + " ad " + baseAry32[idx]);

			printPowerSet(baseAry32, prefix.cNA(baseAry32[idx]), idx + 1, lv);

		}
	}

	/**
	 * To gen all subset.
	 */
	public static void printPowerSetByAry32(int[] baseAry32, int[] prefix, int iBase, int iPrefix, int lv) {

		lv++;

		// 特殊寫法 終止條件
		O.lv(lv, "iBase=" + iBase + " iPrefix=" + iPrefix + " fin " + toStrByAry32(prefix, iPrefix));

		for (; iBase != baseAry32.length; iBase++) {

			// O.lv(lv, "prefix=" + Arrays.toString(prefix) + " ad " + baseAry32[iBase]);

			prefix[iPrefix] = baseAry32[iBase];

			printPowerSetByAry32(baseAry32, prefix, iBase + 1, iPrefix + 1, lv);

		}
	}

	public static void main(String[] sAry) throws Throwable {

		int[] ary = { 10, 20, 30 };

		O.l("ary=");
		O.l(ary);
		O.l("=======");

		printPowerSet(ary, new Seq32(), 0, 0);

		O.l("B.n32=" + B.n32);
		B.n32 = 0;

	}
}
