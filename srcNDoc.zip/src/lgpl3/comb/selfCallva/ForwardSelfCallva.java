package lgpl3.comb.selfCallva;

import lgpl3.o.O;
import lgpl3.shuffle.Shuffler;

/**
 * 本類別前進式自己呼叫自己的人.<br/>
 * To call self forward.
 *
 * @version 2022/12/04_10:00:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=ForwardSelfCallva" >src</a>
 *
 * @see Recur
 */
public abstract class ForwardSelfCallva extends ForwardSelfCallva_A {

	/**
	 * To find max by recursion.
	 */
	public static int srhByRightLeft(int[] ary32, int target, int lIdx, int rIdx /* exclusive */) { // l: left, r: right

		int midIdx = lIdx + ((rIdx - lIdx) >>> 1); // 0 1 2 3 4 => 0 + (5-0)/2

		if (lIdx + 1 == rIdx)

			return ((ary32[midIdx] == target) ? midIdx : -1);
		else {

			int foundIdx = srhByRightLeft(ary32, target, lIdx, midIdx);

			if (foundIdx >= 0)

				return foundIdx;
			else
				return srhByRightLeft(ary32, target, midIdx, rIdx); // 5 6 7 8 => 5 + (9-5)/2

		}
	}

	public static void main(String[] sAry) throws Throwable {

		int[] baseAry = { 10, -40, 20, 50, 89, 30 };
		int target = 89;

		Shuffler.shuffle(baseAry);

		O.l("baseAry=");
		O.l(baseAry);
		O.l("==========");

		int foundIdx = ForwardSelfCallva.srhByRightLeft(baseAry, target, 0, baseAry.length);

		if (foundIdx != -1)
			O.eq(baseAry[foundIdx], target);

		O.l("foundIdx=" + foundIdx);

	}
}
