package lgpl3.comb.selfCallva;

/**
 * 本类别递归娃.<br/>
 * To do some recursion exercise.
 *
 * @version 2021/09/02_22:10:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Recur" >Recur.java</a>
 *
 */
public abstract class Recur extends BackwardSelfCallva_A {

}
