package lgpl3.comb.selfCallva;

import lgpl3.o.O;
import lgpl3.shuffle.Shuffler;

/**
 * 本类别递归娃.<br/>
 * To do some recursion exercise.
 *
 * @version 2022/12/24_10:20:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Recur" >src</a>
 *
 */
public abstract class Recur extends BackwardSelfCallva_A {

	private static final Class<?> THIS = Recur.class;

	/**
	 * To search.
	 */
	// l: left
	// r: right
	public static int srhByRightLeft(int[] ary32 /* unsorted */, int key32, int lIdx, int rIdx /* exclusive */) {

		int range = (rIdx - lIdx) >>> 1; // 0 1 2 3 4 => 0 + (5-0)/2

		if (lIdx + 1 == rIdx) return ((ary32[lIdx] == key32) ? lIdx : -1); // 終止條件

		int foundIdx; // 5 6 7 8 => 5 + (9-5)/2

		if ((foundIdx = srhByRightLeft(ary32, key32, lIdx, (lIdx + range))) >= 0) return foundIdx;

		return srhByRightLeft(ary32, key32, (lIdx + range), rIdx);

	}

	/**
	 * To search.
	 */
	// l: left
	// r: right
	public static int srhByDiv3Part(int[] ary32 /* unsorted */, int key32, int lIdx, int rIdx /* exclusive */) {

		int range = (rIdx - lIdx) / 3; // 0 1 2 3 4 => 0 + (5-0)/3

		int idx1_3 = lIdx + range;

		termCodi: { // 終止條件

			if (lIdx + 2 == rIdx)

				if (ary32[lIdx + 1] == key32) return (lIdx + 1);

				else return ((ary32[lIdx] == key32) ? lIdx : -1);

			if (lIdx + 1 == rIdx) return ((ary32[lIdx] == key32) ? lIdx : -1);

		} // 終止條件 結束

		int foundIdx;

		// 5 6 7 8 => 5 + (9-5)/3

		if ((foundIdx = srhByRightLeft(ary32, key32, lIdx, idx1_3)) >= 0 ||

				(foundIdx = srhByRightLeft(ary32, key32, idx1_3, (idx1_3 + range))) >= 0)

			return foundIdx;

		return srhByRightLeft(ary32, key32, (idx1_3 + range), rIdx);

		// return -1; // 符合人性的寫法

	}

	public static void main(String[] sAry) throws Throwable {

		int[] ary = { 10, -40, 20, 50, 89, 30, 80 };
		int key = 890;

		Shuffler.shuffle(ary);

		O.l("ary=");
		O.l(ary);
		O.l("key=" + key);

		int foundIdx2 = srhByRightLeft(ary, key, 0, ary.length);
		int foundIdx3 = srhByDiv3Part(ary, key, 0, ary.length);

		if (foundIdx2 != -1) O.eq(ary[foundIdx2], key);

		if (foundIdx3 != -1) O.eq(ary[foundIdx3], key);

		O.l("foundIdx3=" + O.eq(foundIdx2, foundIdx3));

	}
}
