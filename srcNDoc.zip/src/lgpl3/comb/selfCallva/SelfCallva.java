package lgpl3.comb.selfCallva;

import java.util.Arrays;

import lgpl3.o.O;

/**
 * 本類別自己呼叫自己的人.<br/>
 * To call self.
 *
 * @version 2022/11/18_18:00:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=SelfCallva" >src</a>
 *
 * @see ForwardSelfCallva
 *
 * @see Recur
 */
public abstract class SelfCallva {

	// private static final Class<?> THIS = SelfCallva.class;

	public static CharSequence charSeqAsSeparator = new StringBuilder(O.S32);

	public static CharSequence lineWr = O.L;

	/**
	 * To sum with tail recursion.
	 */
	public static int sum(int n, int lv) {

		if (n == 0)

			return 0;

		return sum(n - 1, ++lv) + n; // 原創 新發現 效能好

		// return n + sum(n - 1, lv + 1); // err, fuck

		// return sum(n - 1, lv + 1) + n;

	}

	/**
	 * To sum with tail recursion.
	 */
	public static int tailRecurSum(int n, int ans) { // 尾遞迴 (tail-recursion) 騙人 原創

		if (n == 0)

			return ans;

		return tailRecurSum(n - 1, ans + n);

	}

	/**
	 * To find max by recursion.
	 */
	public static int findMax(int[] ary, int idx) {

		if (idx == 0)

			return ary[idx];

		int preMax = findMax(ary, idx - 1);

		return ((ary[idx] > preMax) ? ary[idx] : preMax);

	}

	/**
	 * To find max by recursion.
	 */
	public static int findMaxByKeepMax(int[] ary, int preMax /* 多此一舉 */, int idx) {

		if (idx == ary.length - 1)

			return ((ary[idx] > preMax) ? ary[idx] : preMax);

		preMax = ((ary[idx] > preMax) ? ary[idx] : preMax);

		return findMaxByKeepMax(ary, preMax, idx + 1);

	}

	/**
	 * To find max by recursion.
	 */
	// l: left
	// r: right
	public static int[] findMinMaxByRightLeft(int[] base, int lIdx, int rIdx /* exclusive */) {

		if (lIdx + 1 == rIdx)

			return new int[] { base[lIdx], base[lIdx] };
		else {

			int midIdx = ((lIdx + rIdx) >>> 1), lBox[], rBox[], kingMin, kingMax, tmpR, tmpL;

			lBox = findMinMaxByRightLeft(base, lIdx, midIdx);

			rBox = findMinMaxByRightLeft(base, midIdx, rIdx);

			kingMin = ((tmpL = lBox[0]) < (tmpR = rBox[0])) ? tmpL : tmpR;

			kingMax = ((tmpR = rBox[1]) > (tmpL = lBox[1])) ? tmpR : tmpL;

			return new int[] { kingMin, kingMax };

		}
	}

	/**
	 * 陣列內元素位置顛倒.<br/>
	 * To reverse.
	 */
	public static void easyRevAry32(int[] ary32, int idx) {

		O.l("idx=" + idx);

		int lenDiv2 = (ary32.length >>> 1), tmp;

		if (idx == lenDiv2)

			return; // good 終止條件要寫

		tmp = ary32[idx];
		ary32[idx] = ary32[ary32.length - 1 - idx];
		ary32[ary32.length - 1 - idx] = tmp;

		easyRevAry32(ary32, idx + 1);

	}

	/**
	 * 陣列內元素位置顛倒.<br/>
	 * 書上寫法.
	 */
	public static void revAry(int[] ary32, int idx) {

		O.l("idx=" + idx);

		int lenDiv2 = (ary32.length >>> 1);

		if (idx == lenDiv2)

			return; // good 終止條件要寫

		int tmp = ary32[idx];
		ary32[idx] = ary32[ary32.length - 1 - idx];

		revAry(ary32, idx + 1); // 此時沒完成交換 fuck

		ary32[ary32.length - 1 - idx] = tmp;

	}

	/**
	 * 大意: 1 ~ curI 決定最後倉庫陣列一次要秀出多少個,<br/>
	 * 而 curI nextI 指標跑動, 去抓元素到倉庫陣列.<br/>
	 * 原本資料結構參考書用 C 語言寫成.
	 */
	public static void printPowerSet(char[] baseCAry, char[] prefix, int endOfPrint, int idx, int lv) { // curI nextI 指標跑動

		lv++;

		if (idx == baseCAry.length) {

			endOfPrint++;

			// O.lv 特殊應用
			O.lv(lv, "lv=" + lv + " " + Arrays.toString(prefix) + " pick " + 1 + " ~ " + endOfPrint + "=>" +

					Arrays.toString(Arrays.copyOfRange(prefix, 1, endOfPrint)) + " fin");

		} else {

			// prefix = prefix.clone();

			printPowerSet(baseCAry, prefix, endOfPrint, idx + 1, lv);

			String tmpS = Arrays.toString(prefix);

			endOfPrint++; // 表示等一下 一次要秀出多少個 從原本秀 2 個, 變成秀 3 個, 秀 4 個

			prefix[endOfPrint] = baseCAry[idx];

			O.lv(lv, "lv=" + lv + " " + tmpS + " ++endOfPrint set ary[" + endOfPrint + "]=" + baseCAry[idx] + " =>" +

					Arrays.toString(prefix));

			printPowerSet(baseCAry, prefix, endOfPrint, idx + 1, lv);

		}
	}

	public static void main(String[] sAry) throws Throwable {

		char[] baseCAry = { ' ', 'A', 'B', 'C', 'D' };
		// char[] baseCAry = { ' ', 'D', 'C', 'B', 'A' };

		O.l("baseCAry=");
		O.l(baseCAry);
		O.l("=======");

		printPowerSet(baseCAry, new char[baseCAry.length], 0, 1, 0);

	}
}
