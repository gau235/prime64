package lgpl3.comb.selfCallva;

import java.util.Arrays;

import lgpl3.o.O;
import lgpl3.o.time.T64;

/**
 * @version 2022/11/18_18:00:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=SelfCallva" >SelfCallva.java</a>
 *
 * @see ForwardSelfCallva
 *
 * @see Recur
 */
public abstract class SelfCallva {

	// private static final Class<?> THIS = SelfCallva.class;

	public static CharSequence charSeqAsSeparator = new StringBuilder(O.S32);

	public static CharSequence lineWr = O.L;

	/**
	 * This reduces the maximum recursion depth from N to log2(N).<br/>
	 * But the search effort still stays O(N).
	 */
	public static int sum(int n, int lv) {

		if (n == 0)

			return 0;

		// return sum(n - 1, ++lv) + n; // 原創 新發現
		// return sum(n - 1, lv+1) + n; // err, fuck

		return n + sum(n - 1, lv + 1);

	}

	/**
	 * This reduces the maximum recursion depth from N to log2(N).<br/>
	 * But the search effort still stays O(N).
	 */
	public static int tailRecurSum(int n, int ans) { // 尾遞迴 (tail-recursion) 騙人 原創

		if (n == 0)

			return ans;

		return tailRecurSum(n - 1, ans + n);

	}

	public static int nOfTest = 18_000;

	public static void main(String[] sAry) throws Throwable {

		long t0Sum = O.t();

		int sum = sum(nOfTest, 1);

		O.l("sum=" + sum + " t=" + T64.difInF32Sec(t0Sum));

	}

	public static void main2(String[] sAry) throws Throwable {

		long t0TailRecurSum = O.t();

		int tailRecurSum = tailRecurSum(nOfTest, 0);

		O.l("tailRecurSum=" + tailRecurSum + " t=" + T64.difInF32Sec(t0TailRecurSum));

	}

	/**
	 * This reduces the maximum recursion depth from N to log2(N).<br/>
	 * But the search effort still stays O(N).
	 */
	public static int[] findMinMax(int[] base, int left, int right) {

		if (left == right)

			return new int[] { base[left], base[right] };
		else {

			int mid = (left + right) >>> 1;

			int[] leftBox = findMinMax(base, left, mid);

			int[] rightBox = findMinMax(base, mid + 1, right);

			int newMin = ((newMin = leftBox[0]) < (mid = rightBox[0])) ? newMin : mid;

			int newMax = ((mid = leftBox[1]) > (newMax = rightBox[1])) ? mid : newMax;

			return new int[] { newMin, newMax };

		}
	}

	/**
	 * The power set.<br/>
	 * 原本資料結構參考書用 C 語言寫成.
	 */
	public static void powerSet(char[] baseCAry, char[] tmpCAry, int from, int to, int n, int lv) {

		lv++;

		if (to > n) {

			O.lv(lv, "from " + 1 + " ~ " + (from + 1) + "=>" + Arrays.toString(tmpCAry) + " =>" +

					Arrays.toString(Arrays.copyOfRange(tmpCAry, 1, from + 1)));

		} else {

			tmpCAry = tmpCAry.clone(); // 原本用 C 語言寫成

			powerSet(baseCAry, tmpCAry, from, to + 1, n, lv);

			String tmpS = Arrays.toString(tmpCAry);

			tmpCAry[from + 1] = baseCAry[to];

			O.lv(lv, tmpS + " idx " + (from + 1) + "=" + baseCAry[to] + " =>" + Arrays.toString(tmpCAry));

			powerSet(baseCAry, tmpCAry, from + 1, to + 1, n, lv);

		}
	}

	public static void main5(String[] sAry) throws Throwable {

		char[] baseCAry = { ' ', 'A', 'B', };

		O.l("baseCAry=");
		O.l(baseCAry);
		O.l("=======");

		powerSet(baseCAry, new char[baseCAry.length], 0, 1, baseCAry.length - 1, 0);

	}
}
