package lgpl3.comb.selfCallva;

import java.util.Arrays;

import lgpl3.o.O;

/**
 * @version 2022/11/18_18:00:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=SelfCallva" >SelfCallva.java</a>
 *
 * @see ForwardSelfCallva
 *
 * @see Recur
 */
public abstract class SelfCallva {

	// private static final Class<?> THIS = SelfCallva.class;

	public static CharSequence charSeqAsSeparator = new StringBuilder(O.S32);

	public static CharSequence lineWr = O.L;

	/**
	 * The power set.<br/>
	 * 原本用 C 語言寫成.
	 */
	public static void powerSet(char[] baseCAry, char[] tmpCAry, int from, int to, int n, int lv) {

		lv++;

		if (to > n) {

			O.lv(lv, "from=" + from + " =>" + Arrays.toString(tmpCAry) + " =>" +

					Arrays.toString(Arrays.copyOfRange(tmpCAry, 1, from + 1)));

		} else {

			tmpCAry = tmpCAry.clone(); // 原本用 C 語言寫成

			powerSet(baseCAry, tmpCAry, from, to + 1, n, lv);

			tmpCAry[from + 1] = baseCAry[to];
			O.lv(lv, "let tmpCAry[" + (from + 1) + "]=" + baseCAry[to]);

			powerSet(baseCAry, tmpCAry, from + 1, to + 1, n, lv);

		}
	}

	public static void main(String[] sAry) throws Throwable {

		char[] baseCAry = { ' ', 'A', 'B', 'C', 'D' };

		O.l("baseCAry=");
		O.l(baseCAry);
		O.l("=======");

		powerSet(baseCAry, new char[baseCAry.length], 0, 1, baseCAry.length - 1, 0);

	}
}
