package lgpl3.comb.selfCallva;

import lgpl3.o.O;

/**
 * @version 2021/12/18_18:00:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=SelfCallva" >SelfCallva.java</a>
 *
 * @see ForwardSelfCallva
 *
 * @see Recur
 */
public abstract class SelfCallva {

	// private static final Class<?> THIS = SelfCallva.class;

	public static CharSequence charSeqAsSeparator = new StringBuilder(O.S32);

	public static CharSequence lineWr = O.L;

}
