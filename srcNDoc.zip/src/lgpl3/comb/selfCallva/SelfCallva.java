package lgpl3.comb.selfCallva;

import java.util.Arrays;

import lgpl3.o.O;

/**
 * 本類別自己呼叫自己的人.<br/>
 * To call self.
 *
 * @version 2022/11/18_18:00:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=SelfCallva" >src</a>
 *
 * @see ForwardSelfCallva
 *
 * @see Recur
 */
public abstract class SelfCallva {

	// private static final Class<?> THIS = SelfCallva.class;

	public static CharSequence charSeqAsSeparator = new StringBuilder(O.S32);

	public static CharSequence lineWr = O.L;

	/**
	 * To sum with tail recursion.
	 */
	public static int sum(int n, int lv) {

		if (n == 0)

			return 0;

		return sum(n - 1, ++lv) + n; // 原創 新發現

		// return n + sum(n - 1, lv + 1); // err, fuck

		// return sum(n - 1, lv + 1) + n;

	}

	/**
	 * To sum with tail recursion.
	 */
	public static int tailRecurSum(int n, int ans) { // 尾遞迴 (tail-recursion) 騙人 原創

		if (n == 0)

			return ans;

		return tailRecurSum(n - 1, ans + n);

	}

	/**
	 * To find max by recursion.
	 */
	public static int findMax(int[] ary, int idx) {

		if (idx == 0)

			return ary[0];

		int localMax = findMax(ary, idx - 1);

		return ((ary[idx] > localMax) ? ary[idx] : localMax);

	}

	/**
	 * To find max by recursion.
	 */
	public static int findMaxByKeepMax(int[] ary, int curMax /* 多此一舉 */, int idx) {

		if (ary[idx] > curMax)

			curMax = ary[idx];

		if (idx == ary.length - 1)

			return curMax;

		return findMaxByKeepMax(ary, curMax, idx + 1);

	}

	/**
	 * To find max by recursion.
	 */
	public static int[] findMinMaxByBiDiv(int[] base, int left, int right) {

		if (left == right)

			return new int[] { base[left], base[right] };
		else {

			int mid = ((left + right) >>> 1), leftBox[], rightBox[], kingMin, kingMax, tmpR, tmpL;

			leftBox = findMinMaxByBiDiv(base, left, mid);

			rightBox = findMinMaxByBiDiv(base, mid + 1, right);

			kingMin = ((tmpL = leftBox[0]) < (tmpR = rightBox[0])) ? tmpL : tmpR;

			kingMax = ((tmpR = rightBox[1]) > (tmpL = leftBox[1])) ? tmpR : tmpL;

			return new int[] { kingMin, kingMax };

		}
	}

	/**
	 * The power set.<br/>
	 * 原本資料結構參考書用 C 語言寫成.
	 */
	public static void powerSet(char[] baseCAry, char[] tmpCAry, int from, int to, int n, int lv) {

		lv++;

		if (to > n) {

			O.lv(lv, "from " + 1 + " ~ " + (from + 1) + "=>" + Arrays.toString(tmpCAry) + " =>" +

					Arrays.toString(Arrays.copyOfRange(tmpCAry, 1, from + 1)));

		} else {

			tmpCAry = tmpCAry.clone(); // 原本用 C 語言寫成

			powerSet(baseCAry, tmpCAry, from, to + 1, n, lv);

			String tmpS = Arrays.toString(tmpCAry);

			tmpCAry[from + 1] = baseCAry[to];

			O.lv(lv, tmpS + " idx " + (from + 1) + "=" + baseCAry[to] + " =>" + Arrays.toString(tmpCAry));

			powerSet(baseCAry, tmpCAry, from + 1, to + 1, n, lv);

		}
	}

	/**
	 * 陣列內元素位置顛倒.<br/>
	 * To reverse.
	 */
	public static void rev(int[] ary32, int idx) {

		O.l("idx=" + idx);

		int lenDiv2 = (ary32.length >>> 1), tmp32;

		if (idx == lenDiv2)

			return;

		tmp32 = ary32[idx];
		ary32[idx] = ary32[ary32.length - 1 - idx];
		ary32[ary32.length - 1 - idx] = tmp32;

		rev(ary32, idx + 1);

	}

	public static void main(String[] sAry) throws Throwable {

		char[] baseCAry = { ' ', 'A', 'B', };

		O.l("baseCAry=");
		O.l(baseCAry);
		O.l("=======");

		powerSet(baseCAry, new char[baseCAry.length], 0, 1, baseCAry.length - 1, 0);

	}
}
