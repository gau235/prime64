package lgpl3.comb.selfCallva.sample;

import lgpl3.comb.selfCallva.SelfCallva;
import lgpl3.o.O;
import lgpl3.o.time.T64;

/**
 * To sum with tail recursion.<br/>
 * TailRecurSum.
 *
 * @version 2022/11/17_10:50:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Ex62_TailRecurSum" >src</a>
 *
 */
public class Ex62_TailRecurSum {

	public static int nOfTest = 18_000;

	public static void main(String[] sAry) throws Throwable {

		long t0Sum = O.t();

		int sum = SelfCallva.sum(nOfTest, 1);

		O.l("sum=" + sum + " t=" + T64.difInF32Sec(t0Sum));

	}

	public static void main2(String[] sAry) throws Throwable {

		long t0TailRecurSum = O.t();

		int tailRecurSum = SelfCallva.tailRecurSum(nOfTest, 0);

		O.l("tailRecurSum=" + tailRecurSum + " t=" + T64.difInF32Sec(t0TailRecurSum));

	}
}
