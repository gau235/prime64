package lgpl3.comb.selfCallva.sample;

import lgpl3.comb.selfCallva.ForwardSelfCallva;
import lgpl3.o.O;

/**
 * powerSetInAry32.<br/>
 * powerSetInAry32.
 *
 * @version 2022/11/27_10:50:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Ex72_PrintPowerSetByAry32" >src</a>
 *
 */
public class Ex72_PrintPowerSetByAry32 {

	public static void main(String[] sAry) throws Throwable {

		int[] ary = { 10, 20, 30 };

		O.l("ary=");
		O.l(ary);
		O.l("=======");

		ForwardSelfCallva.printPowerSetByAry32(ary, new int[ary.length], 0, 0, 0);

	}
}
