package lgpl3.comb.selfCallva.sample;

import lgpl3.comb.selfCallva.SelfCallva;
import lgpl3.o.O;

/**
 * powerSetByInt32.<br/>
 * powerSetByInt32.
 *
 * @version 2022/11/27_10:50:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Ex70_PrintPowerSetByInt32" >src</a>
 *
 */
public class Ex70_PrintPowerSetByInt32 {

	public static void main(String[] sAry) throws Throwable {

		int[] base = { 1000, 200, 30, 4 }; // 1234 = 1000+200+30+4

		O.l("base=");
		O.l(base);
		O.l("=======");

		SelfCallva.printPowerSetByInt32(base, 0, 0);

	}
}
