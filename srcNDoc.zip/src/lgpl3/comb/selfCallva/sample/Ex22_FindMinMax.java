package lgpl3.comb.selfCallva.sample;

import java.util.Arrays;

import lgpl3.comb.selfCallva.SelfCallva;
import lgpl3.o.B;
import lgpl3.o.O;
import lgpl3.o.ary.Ary32va;
import lgpl3.shuffle.Shuffler;

/**
 * This reduces the maximum recursion depth from N to log2(N).<br/>
 * But the search effort still stays O(N).
 *
 * @version 2022/12/03_08:50:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Ex22_FindMinMax" >src</a>
 *
 */
public class Ex22_FindMinMax {

	public static void main(String[] sAry) throws Throwable {

		O.isDev = B.O;

		int[] ary = { 13, 60, 20, 50, 89, 30 };

		O.l("ary=");
		O.l(Shuffler.shuffle(ary));
		O.l("==========");

		O.l(SelfCallva.findMinMaxByRightLeft(ary, 0, ary.length));

		for (int i = 0; i < 1_000; i++)

			Shuffler.shuffle(ary);

		if (!Arrays.equals(Ary32va.findMinMaxByAryOfEvenOdd(ary), Ary32va.findMinMaxByGroupHeadTail(ary)))

			O.x();

	}
}
