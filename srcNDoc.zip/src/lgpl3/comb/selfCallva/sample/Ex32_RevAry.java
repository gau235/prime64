package lgpl3.comb.selfCallva.sample;

import java.util.Arrays;

import lgpl3.comb.selfCallva.SelfCallva;
import lgpl3.o.O;
import lgpl3.o.ary.Ary32va;

/**
 * To sum with tail recursion.<br/>
 * TailRecurSum.
 *
 * @version 2022/11/17_10:50:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Ex32_RevAry" >src</a>
 *
 */
public class Ex32_RevAry {

	public static void main(String[] sAry) throws Throwable {

		int[] baseAry = { 10, 30, 70 };
		int[] clonedBaseAry = baseAry.clone();

		O.l("baseAry=");
		O.l(baseAry);
		O.l("=======");

		SelfCallva.rev(clonedBaseAry, 0);

		O.l(clonedBaseAry);

		if (!Arrays.equals(clonedBaseAry, Ary32va.rev(baseAry)))

			O.x();

	}
}
